"""
MIDI Manipulator Client. Copy of the MusicXML engine. The original file is unchanged.

Skips Sibelius fretboard diagrams (ChordWithFretBoard) so a guitar MusicXML
file does not crash. Writes MusicXML 3.1 so Sibelius 2021.2 build 3268 can
import the file. music21's own default is 4.0, which that Sibelius build
rejects and then freezes on.
"""

# =============================================================================
# DEPENDENCIES (install before first use)
# =============================================================================
# Python 3.7+. Standard library: argparse, copy, os, sys, typing.
#
# External (pip):
#   pip install music21
#
# That is the only required package. music21 reads/writes MusicXML and many
# other formats.
# =============================================================================
# PATHS WITH SPACES OR QUOTES
# =============================================================================
# File paths often contain spaces (e.g. "My Song.musicxml"). This script handles
# them: when you type or paste a path in the menu, spaces are preserved and
# surrounding quotes are stripped, so you can paste paths like:
#   /Users/me/My Folder/My Song.musicxml
#   "C:\Documents\My Song.xml"
# Do not run the path as a shell command; enter it only when the script asks
# for "Input MusicXML file path" or "Output MusicXML file path".
# =============================================================================
# FEATURES (menu options 1–8, 0)
# =============================================================================
# 1. Merge all parts into one
# 2. Min pitch (raise notes below) — e.g. 40 = E2
# 3. Remove unison duplicates
# 4. Remove redundant pitch classes (one note per note name in chords)
# 5. Quantize timing (whole → thirtysecond)
# 6. Add text annotations (lyric, expression, fingering, articulation)
# 7. Auto-number (guitar string or finger labels)
# 8. Process MusicXML
# 0. Quit
# =============================================================================
# HOW TO USE
# =============================================================================
# Menu:  python MIDI_manipulator_XML_MASTER3.py
# CLI:   python MIDI_manipulator_XML_MASTER3.py -i input.musicxml -o output.musicxml [options]
# =============================================================================

import argparse
import os
import random
import re
import sys
import xml.etree.ElementTree as ET
from copy import deepcopy
from typing import Callable, Dict, List, Optional, Set, Tuple

from music21 import (
    articulations,
    chord,
    clef,
    converter,
    defaults,
    expressions,
    instrument,
    interval,
    key,
    layout,
    meter,
    note,
    stream,
)


GRID_MAP = {
    "whole": 4.0,
    "half": 2.0,
    "quarter": 1.0,
    "eighth": 0.5,
    "sixteenth": 0.25,
    "thirtysecond": 0.125,
}

DEFAULT_TIME_WINDOW = 0.01

GUITAR_STRINGS: List[Tuple[int, int]] = [
    (6, 40), (5, 45), (4, 50), (3, 55), (2, 59), (1, 64),
]


def load_score(path: str) -> stream.Score:
    return converter.parse(path)


def save_score(score: stream.Score, path: str) -> None:
    """Write MusicXML 3.1, which Sibelius 2021.2 build 3268 can import.

    music21 10 writes version 4.0 unless this is set for the duration of the
    save. Sibelius then shows "newer version of MusicXML" and freezes when
    Yes is chosen. The desktop script is left on music21's own default.

    A path ending in .mxl is a zip. music21 builds that zip immediately, and
    reading the zip as text fails at the first binary byte. Write the plain
    MusicXML, adjust the tab staff, then compress.
    """
    previous = defaults.musicxmlVersion
    defaults.musicxmlVersion = "3.1"
    wants_mxl = str(path).lower().endswith(".mxl")
    xml_path = os.path.splitext(path)[0] + ".musicxml" if wants_mxl else path
    try:
        score.write("musicxml", fp=xml_path, compress=False)
    finally:
        defaults.musicxmlVersion = previous
    _repair_guitar_tab_export(xml_path)
    if wants_mxl:
        from music21.musicxml import archiveTools
        archiveTools.compressXML(
            xml_path,
            deleteOriginal=True,
            silent=True,
            strictMxlCheck=False,
        )


def _source_is_guitar_written(part) -> bool:
    """True when this staff is already written an octave above sounding pitch."""
    for inst in part.recurse().getElementsByClass(instrument.Instrument):
        trans = getattr(inst, "transposition", None)
        if trans is not None and getattr(trans, "semitones", None) == -12:
            return True
    for clef_obj in part.recurse().getElementsByClass(clef.Clef):
        if getattr(clef_obj, "octaveChange", 0) not in (0, None):
            return True
    return False


def _raise_written_octave(elem) -> None:
    """Guitar writes the note an octave higher than it sounds. No little 8 on the clef."""
    pitches = list(getattr(elem, "pitches", ()))
    for pitched in pitches:
        if pitched.midi <= 115:
            pitched.midi += 12


def merge_parts(score: stream.Score) -> stream.Score:
    """Put every staff into one unnamed guitar treble staff.

    music21 10 uses flatten(), not flat. Sibelius guitar MusicXML is read as a
    PartStaff, which is the object in "Part staff object has no attribute flat".
    The same pitches at the same moment are kept once, so a notation staff and
    its tab staff do not copy every note twice.

    Concert-pitch notes are written up an octave, and the part is marked so
    they still sound where they did. A plain treble clef is used, with no 8.
    """
    merged_score = stream.Score()
    merged_part = stream.Part()
    merged_part.partName = ""
    merged_part.partAbbreviation = None
    merged_part.style.printPartName = False
    merged_part.style.printPartAbbreviation = False
    guitar = instrument.Instrument()
    guitar.instrumentName = None
    guitar.instrumentAbbreviation = None
    guitar.midiProgram = None
    guitar.partName = None
    guitar.partAbbreviation = None
    guitar.transposition = interval.Interval("P-8")
    merged_part.insert(0, guitar)
    merged_part.insert(0, clef.TrebleClef())
    seen = set()
    for part in score.parts:
        shift = not _source_is_guitar_written(part)
        flat = part.flatten()
        for elem in flat.notesAndRests:
            if elem.__class__.__name__ == "ChordWithFretBoard":
                continue
            if hasattr(elem, "pitches"):
                pitches = tuple(sorted(int(round(p.midi)) for p in elem.pitches))
            else:
                pitches = ()
            key = (round(float(elem.offset), 5), pitches)
            if key in seen:
                continue
            seen.add(key)
            copied = deepcopy(elem)
            if shift:
                _raise_written_octave(copied)
            merged_part.insert(float(elem.offset), copied)
    if score.metadata:
        merged_score.insert(0, score.metadata)
    merged_score.append(merged_part)
    return merged_score


def _pitched_notes(container):
    """Notes that have a single .pitch.

    Sibelius MusicXML often includes guitar chord diagrams. music21 turns those
    into tablature.ChordWithFretBoard, which shows up in recurse().notes but has
    no .pitch. This is not the old Sibelius ManuScript plugin; skip those objects.
    Real chords (several pitches) are skipped here too — they are not single notes.
    """
    for n in container.recurse().notes:
        if hasattr(n, "pitch"):
            yield n


def lift_notes_below_pitch(score: stream.Score, min_pitch: int) -> None:
    """Raise sounding pitches below min_pitch by octaves until they fit.

    Guitar writes an octave above the sound. The check uses the sounding
    pitch, so a merged staff still lifts a note that is drawn as E2 but
    sounds as E1.
    """
    def shift_for(event) -> int:
        inst = event.getContextByClass(instrument.Instrument)
        if inst is not None and inst.transposition is not None:
            semitones = getattr(inst.transposition, "semitones", None)
            if semitones:
                return int(semitones)
        return 0

    def raise_into_range(pitched, sounding_offset: int) -> None:
        while pitched.midi + sounding_offset < min_pitch and pitched.midi <= 115:
            pitched.midi += 12

    for n in _pitched_notes(score):
        raise_into_range(n.pitch, shift_for(n))
    for part in score.parts:
        for chord_obj in list(part.recurse().getElementsByClass("Chord")):
            if chord_obj.__class__.__name__ == "ChordWithFretBoard":
                continue
            if type(chord_obj).__module__.startswith("music21.harmony"):
                continue
            sounding_offset = shift_for(chord_obj)
            for pitched in chord_obj.pitches:
                raise_into_range(pitched, sounding_offset)


def _group_notes_by_time(part: stream.Part, time_window: float) -> Dict[int, List[note.Note]]:
    buckets: Dict[int, List[note.Note]] = {}
    for n in _pitched_notes(part):
        key = round(n.offset / time_window)
        buckets.setdefault(key, []).append(n)
    return buckets


def _remove_element(elem) -> None:
    parent = elem.activeSite
    if parent is not None:
        parent.remove(elem)


def remove_unison_notes(score: stream.Score, time_window: float = DEFAULT_TIME_WINDOW) -> None:
    for part in score.parts:
        buckets = _group_notes_by_time(part, time_window)
        for notes_at_time in buckets.values():
            seen: Set[int] = set()
            for n in sorted(notes_at_time, key=lambda x: (x.offset, x.pitch.midi)):
                midi_pitch = int(round(n.pitch.midi))
                if midi_pitch in seen:
                    _remove_element(n)
                else:
                    seen.add(midi_pitch)


def remove_redundant_pitch_classes(
    score: stream.Score, time_window: float = DEFAULT_TIME_WINDOW
) -> None:
    """Drop a lower octave when the same note name sounds together.

    A5 is kept and A4 is removed. The same rule applies inside a chord.
    Chord names are left alone.
    """
    for part in score.parts:
        buckets = _group_notes_by_time(part, time_window)
        for notes_at_time in buckets.values():
            seen_classes: Set[int] = set()
            for n in sorted(notes_at_time, key=lambda x: (x.offset, -x.pitch.midi)):
                pitch_class = n.pitch.pitchClass
                if pitch_class in seen_classes:
                    _remove_element(n)
                else:
                    seen_classes.add(pitch_class)
        for chord_obj in list(part.recurse().getElementsByClass("Chord")):
            if chord_obj.__class__.__name__ == "ChordWithFretBoard":
                continue
            if type(chord_obj).__module__.startswith("music21.harmony"):
                continue
            pitches = list(chord_obj.pitches)
            kept = []
            for pitched in pitches:
                lower_than_another = any(
                    other.pitchClass == pitched.pitchClass and other.midi > pitched.midi
                    for other in pitches
                )
                if not lower_than_another:
                    kept.append(pitched)
            if len(kept) != len(pitches) and kept:
                chord_obj.pitches = tuple(kept)


def quantize_score(score: stream.Score, grid_label: str) -> None:
    grid = GRID_MAP[grid_label]
    eps = 1e-6
    for part in score.parts:
        for n in list(part.recurse().notesAndRests):
            if n.__class__.__name__ == "ChordWithFretBoard":
                continue
            if n.duration.isGrace:
                continue
            parent = n.activeSite
            if parent is None:
                continue
            old_offset = n.offset
            new_offset = round(old_offset / grid) * grid
            if abs(new_offset - old_offset) > eps:
                parent.remove(n)
                parent.insert(new_offset, n)
            new_duration = max(grid, round(n.quarterLength / grid) * grid)
            n.quarterLength = new_duration


def add_text_to_notes(
    score: stream.Score,
    text_type: str = "expression",
    text: Optional[str] = None,
    filter_func: Optional[Callable] = None,
) -> None:
    if text_type == "lyric":
        default_text = text or "la"
        for n in _pitched_notes(score):
            if filter_func is None or filter_func(n):
                n.addLyric(default_text)
    elif text_type == "expression":
        default_text = text or "con fuoco"
        for part in score.parts:
            for n in _pitched_notes(part):
                if filter_func is None or filter_func(n):
                    measure = n.getContextByClass('Measure')
                    if measure is not None:
                        expr = expressions.TextExpression(default_text)
                        expr.placement = 'above'
                        measure.insert(n.offset, expr)
    elif text_type == "fingering":
        default_text = text or "1"
        for n in _pitched_notes(score):
            if filter_func is not None and not filter_func(n):
                continue
            fingering = articulations.Fingering(default_text)
            n.articulations.append(fingering)
    elif text_type == "articulation":
        articulation_type = text or "staccato"
        for n in _pitched_notes(score):
            if filter_func is None or filter_func(n):
                if articulation_type.lower() == "staccato":
                    n.articulations.append(articulations.Staccato())
                elif articulation_type.lower() == "accent":
                    n.articulations.append(articulations.Accent())
                elif articulation_type.lower() == "tenuto":
                    n.articulations.append(articulations.Tenuto())
                elif articulation_type.lower() == "fermata":
                    n.articulations.append(articulations.Fermata())


def add_text_by_pitch(
    score: stream.Score,
    pitch_midi: int,
    text: str,
    text_type: str = "expression",
) -> None:
    def pitch_filter(n):
        return hasattr(n, 'pitch') and int(round(n.pitch.midi)) == pitch_midi
    add_text_to_notes(score, text_type=text_type, text=text, filter_func=pitch_filter)


def add_text_by_rhythm(
    score: stream.Score,
    offset: float,
    text: str,
    text_type: str = "expression",
) -> None:
    def rhythm_filter(n):
        return abs(n.offset - offset) < 0.01
    add_text_to_notes(score, text_type=text_type, text=text, filter_func=rhythm_filter)


def compute_basic_guitar_string(midi_pitch: int) -> int:
    for string_num, open_pitch in sorted(GUITAR_STRINGS, key=lambda x: x[1], reverse=True):
        if midi_pitch >= open_pitch:
            return string_num
    return GUITAR_STRINGS[-1][0]


def compute_guitar_string_and_finger(midi_pitch: int) -> Optional[Tuple[int, int]]:
    """First-position string and finger (0=open). Prefer the lowest fret (open first).

    B3 (59) must be open B string (2, 0), not 4th fret on the G string (3, 4).
    """
    best: Optional[Tuple[int, int]] = None
    for string_num, open_pitch in GUITAR_STRINGS:
        delta = midi_pitch - open_pitch
        if 0 <= delta <= 4:
            if best is None or delta < best[1] or (delta == best[1] and string_num < best[0]):
                best = (string_num, delta)
    return best


def _auto_number_digit(midi_pitch: int, mode: str) -> str:
    """One visible digit for a pitch.

    string: guitar string 6 (low E) through 1 (high E).
    finger: 0 open through 4 pinky, when the note is within four frets of an
    open string. Farther up the neck there is no first-position finger, so the
    string number is used and the pitch still gets a digit.
    """
    if mode == "string":
        return str(compute_basic_guitar_string(midi_pitch))
    result = compute_guitar_string_and_finger(midi_pitch)
    if result is None:
        return str(compute_basic_guitar_string(midi_pitch))
    _, finger = result
    return str(finger)


def _sounding_from_written(event, written: int) -> int:
    """Sounding pitch for a written MIDI number on this note's staff."""
    inst = event.getContextByClass(instrument.Instrument)
    if inst is not None and inst.transposition is not None:
        semitones = getattr(inst.transposition, "semitones", None)
        if semitones:
            return written + int(semitones)
    return written


def _sounding_midi(event) -> int:
    """Pitch the note actually sounds, not the octave guitar writes it in.

    A merged guitar staff draws E3 as E4 and marks the part an octave lower.
    Fingering has to use E3, or the open high E (0) is applied to the wrong note.
    """
    return _sounding_from_written(event, int(round(event.pitch.midi)))


def _midi_for_auto_number(event, written_midi: int, fingering_octave_lower: bool) -> int:
    """MIDI pitch used for string/finger digits (after transposition, optional −12)."""
    sounding = _sounding_from_written(event, written_midi)
    if fingering_octave_lower:
        sounding -= 12
    return sounding


def _is_chord_name(event) -> bool:
    """A written chord symbol such as C or Am, not notes that sound."""
    return type(event).__module__.startswith("music21.harmony")


def _offset_in_part(event, part) -> float:
    try:
        return round(float(event.getOffsetInHierarchy(part)), 5)
    except Exception:
        return round(float(event.offset), 5)


def _close_to_note_y(event, pitched=None) -> float:
    """Tenths above the page origin of the top staff line, just over this note.

    MusicXML default-y is measured from the top line. Expression text with no
    position sits well above the staff. A small offset from the notehead is
    about where Sibelius draws fingering.
    """
    pitched = event.pitch if pitched is None else pitched
    clef_obj = event.getContextByClass(clef.Clef)
    lowest = getattr(clef_obj, "lowestLine", None) if clef_obj is not None else None
    if not lowest:
        lowest = 31  # treble, E4
    top_line = lowest + 8
    note_center = (pitched.diatonicNoteNum - top_line) * 5
    return note_center + 15


def _place_expression_text(event, text: str, placed: Set[Tuple[int, float, str]], pitched=None) -> None:
    """One plain digit just above the notehead.

    After a merge the notes sit in a bare part with no measures yet, so the
    words go on that part and music21 builds the measures around them.
    """
    measure = event.getContextByClass(stream.Measure)
    site = measure if measure is not None else event.activeSite
    if site is None:
        return
    if measure is not None:
        try:
            offset = float(event.getOffsetInHierarchy(measure))
        except Exception:
            offset = float(event.offset)
    else:
        offset = float(event.offset)
    key = (id(site), round(offset, 5), text)
    if key in placed:
        return
    placed.add(key)
    expr = expressions.TextExpression(text)
    expr.style.fontSize = 10
    expr.style.fontStyle = "normal"
    target = pitched if pitched is not None else (event.pitch if hasattr(event, "pitch") else None)
    if target is not None:
        expr.style.absoluteY = _close_to_note_y(event, target)
    site.insert(offset, expr)


def _above_a5_for_fingering(event, pitched, fingering_octave_lower: bool) -> bool:
    return _midi_for_auto_number(event, int(round(pitched.midi)), fingering_octave_lower) > 81


def _write_number(event, label: str, placed: Set[Tuple[int, float, str]], sibelius_fingering: bool, pitched=None) -> None:
    if sibelius_fingering and hasattr(event, "pitch"):
        if hasattr(event, "articulations"):
            event.articulations = [
                mark for mark in event.articulations
                if not isinstance(mark, articulations.Fingering)
            ]
        marking = articulations.Fingering(label)
        marking.placement = "above"
        event.articulations.append(marking)
        return
    _place_expression_text(event, label, placed, pitched=pitched)


def _moment_key(part: stream.Part, event) -> Tuple[int, int, float]:
    measure = event.getContextByClass(stream.Measure)
    number = int(getattr(measure, "number", 0) or 0)
    if measure is not None:
        try:
            beat = round(float(event.getOffsetInHierarchy(measure)), 4)
        except Exception:
            beat = round(float(event.offset), 4)
    else:
        beat = round(float(event.offset), 4)
    return (id(part), number, beat)


def _parts_for_auto_number(score: stream.Score) -> List[stream.Part]:
    """Non-tab parts only; in a bracketed group, number just the first notation staff."""
    skip_ids: Set[int] = set()
    for el in score:
        if not isinstance(el, layout.StaffGroup):
            continue
        members = [m for m in el if isinstance(m, stream.Part)]
        non_tab = [m for m in members if not _part_is_tab(m)]
        for extra in non_tab[1:]:
            skip_ids.add(id(extra))
        for tab_part in members:
            if _part_is_tab(tab_part):
                skip_ids.add(id(tab_part))
    parts: List[stream.Part] = []
    seen: Set[int] = set()
    for part in score.parts:
        pid = id(part)
        if pid in skip_ids or pid in seen or _part_is_tab(part):
            continue
        parts.append(part)
        seen.add(pid)
    return parts


def _strip_auto_number_from_part(part: stream.Part) -> None:
    digit_expr = re.compile(r"^[0-6]$")
    for measure in part.getElementsByClass(stream.Measure):
        for expr in list(measure.getElementsByClass(expressions.TextExpression)):
            if digit_expr.match(str(getattr(expr, "content", "") or "").strip()):
                measure.remove(expr)
    for event in part.recurse().notes:
        if hasattr(event, "articulations"):
            event.articulations = [
                mark for mark in event.articulations
                if not isinstance(mark, articulations.Fingering)
            ]


def _append_sibelius_fingering(event, digit: str) -> None:
    if hasattr(event, "articulations"):
        event.articulations = [
            mark for mark in event.articulations
            if not isinstance(mark, articulations.Fingering)
        ]
    marking = articulations.Fingering(digit)
    marking.placement = "above"
    event.articulations.append(marking)


def add_auto_number_annotations(
    score: stream.Score,
    mode: str = "string",
    sibelius_fingering: bool = False,
    fingering_octave_lower: bool = False,
) -> None:
    """Put one digit on each notation note. Tab staves are skipped entirely.

    Chord names (C, Am, G7) are not numbered. A written pitch above A5 is
    skipped. At one moment on a staff, only the lowest note is labeled when
    several note objects share that offset. Sibelius fingering gets a single
    digit per note (not several fingerings on one chord).
    """
    if mode not in ("string", "finger"):
        raise ValueError(f"Unsupported auto number mode '{mode}'.")
    labeled_moments: Set[Tuple[int, int, float]] = set()
    placed: Set[Tuple[int, float, str]] = set()
    for part in _parts_for_auto_number(score):
        _strip_auto_number_from_part(part)
        pitched_at: Dict[Tuple[int, int, float], list] = {}
        for event in part.recurse().notes:
            if event.__class__.__name__ == "ChordWithFretBoard" or _is_chord_name(event):
                continue
            if isinstance(event, note.Note):
                if event.duration.isGrace:
                    continue
                if not hasattr(event, "pitch"):
                    continue
                pitched_at.setdefault(_moment_key(part, event), []).append(event)
            elif isinstance(event, chord.Chord) and event.pitches:
                pitched_at.setdefault(_moment_key(part, event), []).append(event)
        for moment, events in pitched_at.items():
            if moment in labeled_moments:
                continue
            notes = [e for e in events if isinstance(e, note.Note)]
            chords = [e for e in events if isinstance(e, chord.Chord)]
            if notes:
                event = sorted(notes, key=lambda e: e.pitch.midi)[0]
                pitch = event.pitch
            elif chords:
                event = chords[0]
                usable = sorted(
                    [p for p in event.pitches if not _above_a5_for_fingering(event, p, fingering_octave_lower)],
                    key=lambda p: p.midi,
                )
                if not usable:
                    continue
                pitch = usable[0]
            else:
                continue
            if isinstance(event, note.Note) and _above_a5_for_fingering(event, event.pitch, fingering_octave_lower):
                continue
            midi = _midi_for_auto_number(event, int(round(pitch.midi)), fingering_octave_lower)
            label = _auto_number_digit(midi, mode)
            labeled_moments.add(moment)
            if sibelius_fingering:
                _append_sibelius_fingering(event, label)
            else:
                _write_number(event, label, placed, False, pitched=pitch)


# Lengths written with at most one tie and at most one dot.
# Shortest is a 16th. Longest is 4 beats.
RHYTHM_LENGTHS = [
    0.25, 0.375, 0.5, 0.75,
    1.0, 1.25, 1.5,
    2.0, 2.25, 2.5, 2.75,
    3.0, 4.0,
]
# One notehead, and how many dots it uses. Two of these tied would be a second tie.
_ONE_NOTE_DOTS = {
    0.25: 0, 0.375: 1, 0.5: 0, 0.75: 1,
    1.0: 0, 1.5: 1, 2.0: 0, 3.0: 1, 4.0: 0,
}


def _bar_quarter_length(part) -> float:
    for el in part.recurse():
        if isinstance(el, meter.TimeSignature):
            return float(el.barDuration.quarterLength)
    return 4.0


def _duration_obeys_tie_and_dot(ql: float, offset: float, bar: float) -> bool:
    """True when this length, starting here, needs at most one tie and one dot.

    A value that stays inside the bar is taken from RHYTHM_LENGTHS, whose
    spellings already obey that. A value that crosses a barline spends its
    one tie on that barline, so each side must be a single notehead and the
    two sides together can have only one dot. The note also has to finish on
    the barline or leave at least a 16th, so the next note is not forced
    into a 32nd.
    """
    ql = round(float(ql), 5)
    if ql not in RHYTHM_LENGTHS:
        return False
    pos = round(offset % bar, 5)
    if pos < 1e-6 or abs(pos - bar) < 1e-6:
        pos = 0.0
    room = round(bar - pos, 5)
    if ql <= room + 1e-6:
        fits = True
    elif ql > room + bar + 1e-6:
        return False
    else:
        left = round(room, 5)
        right = round(ql - room, 5)
        if left not in _ONE_NOTE_DOTS or right not in _ONE_NOTE_DOTS:
            return False
        if _ONE_NOTE_DOTS[left] + _ONE_NOTE_DOTS[right] > 1:
            return False
        fits = True
    if not fits:
        return False
    end_pos = round((pos + ql) % bar, 5)
    if end_pos < 1e-6 or abs(end_pos - bar) < 1e-6:
        return True
    return round(bar - end_pos, 5) + 1e-6 >= 0.25


def _random_rhythm_length(offset: float, bar: float) -> float:
    choices = [ql for ql in RHYTHM_LENGTHS if _duration_obeys_tie_and_dot(ql, offset, bar)]
    if choices:
        return random.choice(choices)
    # Land on the barline with one undotted note when the grid has a gap.
    pos = round(offset % bar, 5)
    if pos < 1e-6:
        pos = 0.0
    room = round(bar - pos, 5)
    if room in _ONE_NOTE_DOTS and _ONE_NOTE_DOTS[room] == 0:
        return room
    return 0.25


def _part_timeline(part):
    """Notes, chords, and rests in the order they are heard. Skip chord names."""
    events = []
    for el in part.recurse().notesAndRests:
        if el.__class__.__name__ == "ChordWithFretBoard":
            continue
        if type(el).__module__.startswith("music21.harmony"):
            continue
        if getattr(getattr(el, "duration", None), "isGrace", False):
            continue
        events.append(el)

    def at(el) -> float:
        try:
            return float(el.getOffsetInHierarchy(part))
        except Exception:
            return float(el.offset)

    events.sort(key=at)
    return events


def _pitch_payload(el):
    if isinstance(el, note.Rest):
        return None
    if hasattr(el, "pitch"):
        return [deepcopy(el.pitch)]
    if hasattr(el, "pitches") and len(el.pitches) > 0:
        return [deepcopy(p) for p in el.pitches]
    return None


def _install_pitches(el, pitches):
    site = el.activeSite
    offset = float(el.offset)
    dur = el.quarterLength
    if len(pitches) == 1 and hasattr(el, "pitch"):
        el.pitch = pitches[0]
        return el
    if len(pitches) > 1 and hasattr(el, "pitches") and not hasattr(el, "pitch"):
        el.pitches = pitches
        return el
    if len(pitches) == 1:
        new = note.Note()
        new.pitch = pitches[0]
    else:
        new = chord.Chord(pitches)
    new.quarterLength = dur
    if site is not None:
        site.remove(el)
        site.insert(offset, new)
    return new


def _retrograde_pitch_list(events):
    indexes = [i for i, el in enumerate(events) if _pitch_payload(el) is not None]
    payloads = [_pitch_payload(events[i]) for i in indexes]
    for index, payload in zip(indexes, reversed(payloads)):
        events[index] = _install_pitches(events[index], payload)


def _reflow(part, events) -> None:
    """Lay events in from the start and drop the old measures.

    Leaving the notes inside the old measures made the file export empty
    once their durations no longer matched the bar.
    """
    keep = []
    seen = set()
    for el in part.recurse():
        if isinstance(el, (instrument.Instrument, clef.Clef, key.KeySignature, meter.TimeSignature)):
            kind = el.__class__.__name__
            if kind in seen:
                continue
            seen.add(kind)
            keep.append(deepcopy(el))
    for el in list(events):
        site = el.activeSite
        if site is not None:
            site.remove(el)
    for el in list(part):
        part.remove(el)
    for el in keep:
        part.insert(0, el)
    when = 0.0
    for el in events:
        part.insert(when, el)
        when += float(el.quarterLength)


def apply_retrograde_and_rhythm(
    score: stream.Score,
    retrograde_pitches: bool = False,
    retrograde_rhythms: bool = False,
    retrograde_both: bool = False,
    randomize_rhythms: bool = False,
) -> None:
    """Reverse pitches, rhythms, or both, then optionally pick new durations.

    Retrograde both is the line played backwards. Random lengths run from a
    sixteenth note through 4 beats. Each one is written with at most one tie
    and a single dot.
    """
    do_pitches = retrograde_pitches or retrograde_both
    do_rhythms = retrograde_rhythms or retrograde_both
    if not (do_pitches or do_rhythms or randomize_rhythms):
        return
    for part in list(score.parts):
        events = _part_timeline(part)
        if not events:
            continue
        if do_pitches and do_rhythms:
            events = list(reversed(events))
        elif do_pitches:
            _retrograde_pitch_list(events)
        if do_rhythms or randomize_rhythms:
            if randomize_rhythms:
                bar = _bar_quarter_length(part)
                when = 0.0
                for el in events:
                    el.quarterLength = _random_rhythm_length(when, bar)
                    when += float(el.quarterLength)
            elif do_rhythms and not do_pitches:
                durations = [float(el.quarterLength) for el in events]
                for el, dur in zip(events, reversed(durations)):
                    el.quarterLength = dur
            _reflow(part, events)


MAX_TAB_FRET = 22

# MusicXML numbers tab lines from the bottom. Line 1 is the low E string.
_TAB_TUNING = (
    (1, "E", "2"),
    (2, "A", "2"),
    (3, "D", "3"),
    (4, "G", "3"),
    (5, "B", "3"),
    (6, "E", "4"),
)


def _best_open_string(midi_pitch: int, used: Set[int]) -> Optional[Tuple[int, int]]:
    """Lowest fret on a free string, within a normal guitar neck."""
    choices = []
    for string_num, open_pitch in GUITAR_STRINGS:
        if string_num in used:
            continue
        fret = midi_pitch - open_pitch
        if 0 <= fret <= MAX_TAB_FRET:
            choices.append((fret, string_num))
    if not choices:
        return None
    return min(choices)


def _marks_at_one_moment(events, tab_octave_lower: bool = False) -> Dict[int, List[Tuple[int, int]]]:
    """String and fret for every pitch sounding at one moment.

    The highest pitch takes a string first. Marks for each event come back
    lowest pitch first, which is the order music21 writes a chord.
    """
    items = []
    for el in events:
        for index, pitched in enumerate(el.pitches):
            items.append((
                el,
                index,
                _midi_for_auto_number(el, int(round(pitched.midi)), tab_octave_lower),
            ))
    chosen: Dict[Tuple[int, int], Tuple[int, int]] = {}
    used: Set[int] = set()
    for el, index, midi_pitch in sorted(items, key=lambda row: -row[2]):
        choice = _best_open_string(midi_pitch, used)
        if choice is None:
            continue
        fret, string_num = choice
        used.add(string_num)
        chosen[(id(el), index)] = (string_num, fret)
    by_event: Dict[int, List[Tuple[int, int]]] = {}
    for el in events:
        order = sorted(
            range(len(el.pitches)),
            key=lambda index: _midi_for_auto_number(
                el, int(round(el.pitches[index].midi)), tab_octave_lower
            ),
        )
        by_event[id(el)] = [
            chosen[(id(el), index)]
            for index in order
            if (id(el), index) in chosen
        ]
    return by_event


def _prepare_tab_event(copied, marks: List[Tuple[int, int]]) -> None:
    """Drop notation fingerings from the tab copy and write string and fret."""
    if hasattr(copied, "articulations"):
        copied.articulations = [
            mark for mark in copied.articulations
            if not isinstance(
                mark,
                (articulations.Fingering, articulations.StringIndication, articulations.FretIndication),
            )
        ]
    if getattr(copied, "lyrics", None):
        copied.lyrics = []
    if getattr(copied, "expressions", None):
        copied.expressions = [
            expr for expr in copied.expressions
            if not isinstance(expr, expressions.TextExpression)
        ]
    for string_num, fret in marks:
        copied.articulations.append(articulations.FretIndication(fret))
        copied.articulations.append(articulations.StringIndication(string_num))


def _sounding_pitch(clone, original, tab_octave_lower: bool = False) -> None:
    """Tab is written where the note sounds. Guitar notation is an octave higher."""
    if not getattr(clone, "pitches", None):
        return
    for pitched in clone.pitches:
        pitched.midi = _midi_for_auto_number(
            original, int(round(pitched.midi)), tab_octave_lower
        )


def _part_is_tab(part: stream.Part) -> bool:
    for clef_obj in part.getElementsByClass(clef.Clef):
        if isinstance(clef_obj, clef.TabClef) or getattr(clef_obj, "sign", None) == "TAB":
            return True
    for clef_obj in part.recurse().getElementsByClass(clef.Clef):
        if isinstance(clef_obj, clef.TabClef) or getattr(clef_obj, "sign", None) == "TAB":
            return True
    name = (getattr(part, "partName", None) or "").lower()
    if "tab" in name:
        return True
    return False


def _score_has_tab(score: stream.Score) -> bool:
    return any(_part_is_tab(part) for part in score.parts)


def _strip_fingering_from_tab_parts(score: stream.Score) -> None:
    """Tab staves should show frets/strings only, never guitar finger or string labels."""
    digit_expr = re.compile(r"^[0-6]$")
    for part in score.parts:
        if not _part_is_tab(part):
            continue
        for event in part.recurse().notes:
            if hasattr(event, "articulations"):
                event.articulations = [
                    mark for mark in event.articulations
                    if not isinstance(mark, articulations.Fingering)
                ]
            if getattr(event, "expressions", None):
                event.expressions = [
                    expr for expr in event.expressions
                    if not (
                        isinstance(expr, expressions.TextExpression)
                        and digit_expr.match(str(getattr(expr, "content", "") or "").strip())
                    )
                ]


def add_guitar_tab(score: stream.Score, tab_octave_lower: bool = False) -> None:
    """Add a separate 6-line tab part under each treble part.

    Sibelius stores the tab as its own part, bracketed under the notation.
    Putting the tab notes in the same part prints them again on the treble
    staff, in unison. The tab part uses the sounding pitch, so a written F4
    on the guitar staff becomes F3, fret 3, on the D string. A file that
    already has a tab part is left alone.
    """
    if _score_has_tab(score):
        return
    for part in list(score.parts):
        tab = stream.Part()
        tab.partName = ""
        tab.partAbbreviation = None
        tab.style.printPartName = False
        tab.style.printPartAbbreviation = False
        tab_clef = clef.TabClef()
        tab_clef.line = 2
        tab.insert(0, tab_clef)
        tab.insert(0, layout.StaffLayout(distance=42, staffNumber=1, staffLines=6))
        events = []
        for el in list(part.recurse()):
            if isinstance(el, (key.KeySignature, meter.TimeSignature)):
                tab.insert(_offset_in_part(el, part), deepcopy(el))
                continue
            if el.__class__.__name__ == "ChordWithFretBoard" or _is_chord_name(el):
                continue
            site = getattr(el, "activeSite", None)
            if isinstance(site, chord.Chord) and site is not el:
                continue
            if not isinstance(el, (note.Note, note.Rest, chord.Chord)):
                continue
            events.append(el)
        pitched_at: Dict[float, list] = {}
        for el in events:
            if isinstance(el, note.Rest) or not getattr(el, "pitches", None):
                continue
            pitched_at.setdefault(_offset_in_part(el, part), []).append(el)
        marks_at = {
            offset: _marks_at_one_moment(group, tab_octave_lower)
            for offset, group in pitched_at.items()
        }
        for el in events:
            clone = deepcopy(el)
            offset = _offset_in_part(el, part)
            marks = marks_at.get(offset, {}).get(id(el), [])
            _prepare_tab_event(clone, marks)
            _sounding_pitch(clone, el, tab_octave_lower)
            tab.insert(offset, clone)
        score.insert(part.offset, tab)
        score.insert(0, layout.StaffGroup([part, tab], symbol="bracket", barTogether=False))


def _xml_name(element) -> str:
    return element.tag.rsplit("}", 1)[-1]


def _xml_children(element, name: str):
    return [child for child in list(element) if _xml_name(child) == name]


def _repair_guitar_tab_export(path: str) -> None:
    """Put one fret on each tab chord note, and declare standard guitar tuning.

    music21 writes every string and fret of a chord onto the first note, and
    it does not write the six-line staff tuning Sibelius needs for a tab staff.
    """
    try:
        text = open(path, encoding="utf-8").read()
    except (OSError, UnicodeDecodeError):
        return
    if "<sign>TAB</sign>" not in text:
        return
    try:
        root = ET.fromstring(text)
    except ET.ParseError:
        return
    changed = False
    for part in list(root):
        if _xml_name(part) != "part":
            continue
        for measure in list(part):
            if _xml_name(measure) != "measure":
                continue
            if _spread_tab_chord_frets(measure):
                changed = True
            if _ensure_tab_staff_details(measure):
                changed = True
    if not changed:
        return
    header, marker, _rest = text.partition("<score-partwise")
    body = ET.tostring(root, encoding="unicode")
    with open(path, "w", encoding="utf-8") as handle:
        if marker and header.strip():
            handle.write(header)
        handle.write(body)


def _note_staff(note_el) -> str:
    for child in _xml_children(note_el, "staff"):
        return (child.text or "").strip()
    return ""


def _technical(note_el):
    for notations in _xml_children(note_el, "notations"):
        found = _xml_children(notations, "technical")
        if found:
            return found[0]
    return None


def _string_fret_pairs(note_el):
    technical = _technical(note_el)
    if technical is None:
        return []
    strings = [child for child in list(technical) if _xml_name(child) == "string"]
    frets = [child for child in list(technical) if _xml_name(child) == "fret"]
    return list(zip(strings, frets))


def _spread_tab_chord_frets(measure) -> bool:
    notes = [el for el in list(measure) if _xml_name(el) == "note"]
    index = 0
    changed = False
    while index < len(notes):
        if _xml_children(notes[index], "chord"):
            index += 1
            continue
        group = [notes[index]]
        cursor = index + 1
        while cursor < len(notes) and _xml_children(notes[cursor], "chord"):
            group.append(notes[cursor])
            cursor += 1
        if len(group) > 1 and _string_count(group[0]) > 1 and all(_string_count(n) == 0 for n in group[1:]):
            pairs = []
            for note_el in group:
                pairs.extend(_string_fret_pairs(note_el))
            if len(pairs) == len(group):
                for note_el in group:
                    technical = _technical(note_el)
                    if technical is None:
                        continue
                    for child in list(technical):
                        if _xml_name(child) in ("string", "fret"):
                            technical.remove(child)
                for note_el, (string_el, fret_el) in zip(group, pairs):
                    technical = _ensure_technical(note_el)
                    technical.append(fret_el)
                    technical.append(string_el)
                changed = True
        index = cursor
    return changed


def _string_count(note_el) -> int:
    technical = _technical(note_el)
    if technical is None:
        return 0
    return sum(1 for child in list(technical) if _xml_name(child) == "string")


def _ensure_technical(note_el):
    notations = _xml_children(note_el, "notations")
    if notations:
        box = notations[0]
    else:
        box = ET.SubElement(note_el, "notations")
    technical = _xml_children(box, "technical")
    if technical:
        return technical[0]
    return ET.SubElement(box, "technical")


def _ensure_tab_staff_details(measure) -> bool:
    attributes = next((el for el in list(measure) if _xml_name(el) == "attributes"), None)
    if attributes is None:
        return False
    tab_clef = None
    for clef_el in _xml_children(attributes, "clef"):
        signs = _xml_children(clef_el, "sign")
        if signs and (signs[0].text or "").strip() == "TAB":
            tab_clef = clef_el
    if tab_clef is None:
        return False
    changed = False
    for line_el in _xml_children(tab_clef, "line"):
        if (line_el.text or "").strip() != "2":
            line_el.text = "2"
            changed = True
    if any(_xml_name(el) == "staff-lines" for el in attributes.iter()):
        details = next(iter(_xml_children(attributes, "staff-details")), None)
        if details is None:
            return changed
        if not details.get("number"):
            details.set("number", "1")
            changed = True
        if not any(_xml_name(el) == "staff-tuning" for el in list(details)):
            for line, step, octave in _TAB_TUNING:
                tuning = ET.SubElement(details, "staff-tuning", {"line": str(line)})
                ET.SubElement(tuning, "tuning-step").text = step
                ET.SubElement(tuning, "tuning-octave").text = octave
            changed = True
        return changed
    details = ET.Element("staff-details")
    details.set("number", tab_clef.get("number") or "1")
    lines = ET.SubElement(details, "staff-lines")
    lines.text = "6"
    for line, step, octave in _TAB_TUNING:
        tuning = ET.SubElement(details, "staff-tuning", {"line": str(line)})
        ET.SubElement(tuning, "tuning-step").text = step
        ET.SubElement(tuning, "tuning-octave").text = octave
    insert_at = list(attributes).index(tab_clef) + 1
    attributes.insert(insert_at, details)
    return True


def _hand_for_event(el) -> str:
    """Treble-clef notes go to the violins. Bass-clef notes go to viola and cello."""
    clef_obj = el.getContextByClass(clef.Clef)
    sign = getattr(clef_obj, "sign", None) if clef_obj is not None else None
    if sign == "F":
        return "bass"
    if sign == "G":
        return "treble"
    staff_number = getattr(el, "staffNumber", None)
    if staff_number == 2:
        return "bass"
    if staff_number == 1:
        return "treble"
    pitches = getattr(el, "pitches", None)
    if pitches:
        return "bass" if int(round(pitches[0].midi)) < 60 else "treble"
    return "treble"


def _quartet_part(name: str, clef_obj, events, meter_key, raise_octave: bool) -> stream.Part:
    part = stream.Part()
    part.partName = name
    part.partAbbreviation = None
    part.style.printPartName = True
    voice = instrument.Instrument()
    voice.instrumentName = name
    voice.partName = name
    voice.instrumentAbbreviation = None
    part.insert(0, voice)
    part.insert(0, clef_obj)
    for offset, el in meter_key:
        part.insert(offset, deepcopy(el))
    for offset, el in events:
        clone = deepcopy(el)
        if raise_octave and getattr(clone, "pitches", None):
            for pitched in clone.pitches:
                if pitched.midi <= 115:
                    pitched.midi += 12
        part.insert(offset, clone)
    return part


def _is_chord_symbol(el) -> bool:
    """A MusicXML chord name, including one that also carries a fretboard frame."""
    return el.__class__.__name__ in ("ChordSymbol", "ChordWithFretBoard") or _is_chord_name(el)


def _remember_chord_symbol(found: List[Tuple[float, list]], seen: set, el, offset: float) -> None:
    pitches = list(getattr(el, "pitches", []) or [])
    if not pitches:
        return
    key_id = round(offset, 5)
    if key_id in seen:
        return
    seen.add(key_id)
    found.append((key_id, pitches))


def _violin_arpeggio_pitches(pitches) -> list:
    """Keep the chord spelling and lift it into the violin range."""
    unique = []
    seen = set()
    for pitched in sorted(pitches, key=lambda item: item.midi):
        midi = int(round(pitched.midi))
        if midi in seen:
            continue
        seen.add(midi)
        unique.append(deepcopy(pitched))
    while unique and min(item.midi for item in unique) < 55 and max(item.midi for item in unique) + 12 <= 88:
        for item in unique:
            item.transpose(12, inPlace=True)
    return unique


def _events_end(events) -> float:
    end = 0.0
    for offset, el in events:
        end = max(end, offset + float(getattr(el, "quarterLength", 0) or 0))
    return end


def _bar_windows(meter_key, end_offset: float):
    """Each bar as (start, length in quarters, length of one written beat)."""
    changes = [(off, el) for off, el in meter_key if isinstance(el, meter.TimeSignature)]
    changes.sort(key=lambda item: item[0])
    if not changes or changes[0][0] > 0:
        changes.insert(0, (0.0, meter.TimeSignature("4/4")))
    windows = []
    for index, (off, time_sig) in enumerate(changes):
        bar_ql = float(time_sig.barDuration.quarterLength)
        beat_ql = 4.0 / float(time_sig.denominator)
        if bar_ql <= 0 or beat_ql <= 0:
            continue
        if index + 1 < len(changes):
            limit = changes[index + 1][0]
        else:
            span = max(0.0, end_offset - off)
            bars = int(span / bar_ql + 1e-6)
            if span - bars * bar_ql > 1e-3 or bars < 1:
                bars = max(1, bars + (1 if span - bars * bar_ql > 1e-3 else 0))
            if span <= 1e-6:
                bars = 0
            limit = off + bars * bar_ql
        cursor = off
        while cursor < limit - 1e-6:
            windows.append((round(cursor, 5), bar_ql, beat_ql))
            cursor += bar_ql
    return windows


def _bass_pitch_at(bass, when: float):
    """Lowest bass pitch that starts on this beat, or is already sounding there."""
    starting = []
    sounding = []
    for offset, el in bass:
        pitches = list(getattr(el, "pitches", None) or [])
        if not pitches:
            continue
        lowest = min(pitches, key=lambda pitched: pitched.midi)
        duration = float(getattr(el, "quarterLength", 0) or 0)
        if abs(offset - when) < 0.02:
            starting.append(lowest)
        elif offset < when < offset + duration - 1e-6:
            sounding.append(lowest)
    if starting:
        return min(starting, key=lambda pitched: pitched.midi)
    if sounding:
        return min(sounding, key=lambda pitched: pitched.midi)
    return None


def _simplified_cello(bass, meter_key, end_offset: float):
    """Two cello notes per bar: beat 1 and beat 3, each held until the next one."""
    events = []
    for bar_start, bar_ql, beat_ql in _bar_windows(meter_key, end_offset):
        attacks = [0.0]
        beat_three = 2.0 * beat_ql
        if beat_three < bar_ql - 0.02:
            attacks.append(beat_three)
        attacks.append(bar_ql)
        for left, right in zip(attacks, attacks[1:]):
            duration = round(right - left, 5)
            if duration <= 0:
                continue
            pitched = _bass_pitch_at(bass, bar_start + left)
            if pitched is None:
                event = note.Rest()
            else:
                event = note.Note()
                event.pitch = deepcopy(pitched)
            event.quarterLength = duration
            events.append((round(bar_start + left, 5), event))
    return events


def _violin_two_arpeggios(chord_symbols, end_offset: float):
    """Eighth-note arpeggios that spell each chord name until the next one."""
    if not chord_symbols:
        return None
    symbols = []
    for offset, pitches in chord_symbols:
        spelled = _violin_arpeggio_pitches(pitches)
        if spelled:
            symbols.append((offset, spelled))
    if not symbols:
        return None
    end = max(end_offset, symbols[-1][0] + 0.5)
    events = []
    if symbols[0][0] > 0.02:
        rest = note.Rest()
        rest.quarterLength = symbols[0][0]
        events.append((0.0, rest))
    for index, (start, spelled) in enumerate(symbols):
        stop = symbols[index + 1][0] if index + 1 < len(symbols) else end
        cursor = start
        step = 0
        while cursor < stop - 1e-4:
            remaining = stop - cursor
            duration = 0.5 if remaining >= 0.5 - 1e-4 else remaining
            event = note.Note()
            event.pitch = deepcopy(spelled[step % len(spelled)])
            event.quarterLength = duration
            events.append((round(cursor, 5), event))
            cursor += duration
            step += 1
    return events


def _collect_piano_hands(score: stream.Score):
    """Split a piano score into treble events, bass events, meter, and chord names."""
    treble = []
    bass = []
    meter_key = []
    chord_symbols = []
    seen_meter = set()
    seen_chords = set()
    for part in list(score.parts):
        for el in list(part.recurse()):
            if isinstance(el, (meter.TimeSignature, key.KeySignature)):
                offset = _offset_in_part(el, part)
                kind = (
                    round(offset, 5),
                    el.__class__.__name__,
                    getattr(el, "fifths", None),
                    getattr(el, "ratioString", None),
                )
                if kind not in seen_meter:
                    seen_meter.add(kind)
                    meter_key.append((offset, deepcopy(el)))
                continue
            if _is_chord_symbol(el):
                _remember_chord_symbol(chord_symbols, seen_chords, el, _offset_in_part(el, part))
                continue
            site = getattr(el, "activeSite", None)
            if isinstance(site, chord.Chord) and site is not el:
                continue
            if not isinstance(el, (note.Note, note.Rest, chord.Chord)):
                continue
            offset = _offset_in_part(el, part)
            if _hand_for_event(el) == "bass":
                bass.append((offset, el))
            else:
                treble.append((offset, el))
    chord_symbols.sort(key=lambda item: item[0])
    end_offset = max(_events_end(treble), _events_end(bass), chord_symbols[-1][0] if chord_symbols else 0.0)
    return treble, bass, meter_key, chord_symbols, end_offset


def _upper_and_bass_for_rules(treble, bass, meter_key, chord_symbols, end_offset, apply_rules: bool, upper_name: str):
    """Leave the upper part on the treble line unless rules turn it into arpeggios.

    The bass part becomes beat 1 and beat 3 only when rules are on.
    """
    upper_events = treble
    lower_events = bass
    if not apply_rules:
        return upper_events, lower_events
    lower_events = _simplified_cello(bass, meter_key, end_offset)
    arpeggios = _violin_two_arpeggios(chord_symbols, end_offset)
    if arpeggios is None:
        print(f"[quartet] No chord symbols found. {upper_name} keeps the treble line.")
    else:
        upper_events = arpeggios
        print(f"[quartet] {upper_name} arpeggios from {len(chord_symbols)} chord symbol(s).")
    return upper_events, lower_events


def _replace_with_quartet(score: stream.Score, parts) -> None:
    for el in list(score):
        if isinstance(el, (stream.Part, layout.StaffGroup)):
            score.remove(el)
    for part in parts:
        score.insert(0, part)
    score.insert(0, layout.StaffGroup(list(parts), symbol="bracket", barTogether=True))


LAN_SYSTEMS_PER_PAGE = 5
LAN_MEASURES_PER_SYSTEM = 4


def _part_measure_at_index(part: stream.Part, index: int) -> Optional[stream.Measure]:
    measures = list(part.getElementsByClass(stream.Measure))
    if index < len(measures):
        return measures[index]
    return None


def _clear_system_page_layout(measure: stream.Measure) -> None:
    for el in list(measure.getElementsByClass((layout.SystemLayout, layout.PageLayout))):
        measure.remove(el)


def _measure_by_number(part: stream.Part, number: int) -> Optional[stream.Measure]:
    for measure in part.getElementsByClass(stream.Measure):
        if int(getattr(measure, "number", 0) or 0) == int(number):
            return measure
    return None


def apply_lan_score_layout(
    score: stream.Score,
    *,
    four_measures_per_system: bool = False,
    five_systems_per_page: bool = False,
    systems_per_page: int = LAN_SYSTEMS_PER_PAGE,
    measures_per_system: int = LAN_MEASURES_PER_SYSTEM,
) -> None:
    """Insert explicit system and/or page breaks for Sibelius-style layout."""
    if not four_measures_per_system and not five_systems_per_page:
        return
    parts = list(score.parts)
    if not parts or measures_per_system < 1 or systems_per_page < 1:
        return
    ref_part = next((p for p in parts if not _part_is_tab(p)), parts[0])
    ref_measures = list(ref_part.getElementsByClass(stream.Measure))
    if len(ref_measures) <= 1:
        print("[layout] LAN: fewer than two measures; no breaks added.")
        return
    score.definesExplicitSystemBreaks = bool(four_measures_per_system)
    score.definesExplicitPageBreaks = bool(five_systems_per_page)
    for part in parts:
        for measure in part.getElementsByClass(stream.Measure):
            _clear_system_page_layout(measure)
    system_index = 0
    for idx in range(1, len(ref_measures)):
        if idx % measures_per_system != 0:
            continue
        system_index += 1
        page_break = five_systems_per_page and system_index % systems_per_page == 0
        need_system = four_measures_per_system
        if not need_system and not page_break:
            continue
        measure_number = int(getattr(ref_measures[idx], "number", idx + 1) or (idx + 1))
        for part in parts:
            measure = _measure_by_number(part, measure_number)
            if measure is None:
                measure = _part_measure_at_index(part, idx)
            if measure is None:
                continue
            if page_break:
                measure.insert(0, layout.PageLayout(isNew=True))
            if need_system:
                measure.insert(0, layout.SystemLayout(isNew=True))
    parts_msg = []
    if four_measures_per_system:
        parts_msg.append(f"{measures_per_system} measures per system")
    if five_systems_per_page:
        parts_msg.append(f"{systems_per_page} systems per page")
    print(f"[layout] LAN: {', '.join(parts_msg)} ({len(ref_measures)} bars).")


def apply_lan_five_systems_per_page(score: stream.Score) -> None:
    """Backward-compatible wrapper: both LAN layout checkboxes on."""
    apply_lan_score_layout(
        score,
        four_measures_per_system=True,
        five_systems_per_page=True,
    )


def piano_to_string_quartet(score: stream.Score, apply_rules: bool = False) -> None:
    """Replace the piano staves with Violin I, Violin II, Viola, and Cello.

    This runs only when that checkbox is on. Both violins receive the treble-clef
    notes, so they can match. Viola and cello receive the bass-clef notes. The
    viola is written an octave higher, on the alto clef. The cello stays in bass.

    The rules checkbox is separate. It simplifies the cello to beat 1 and beat 3,
    and it turns Violin II into eighth-note arpeggios of the chord names.
    """
    treble, bass, meter_key, chord_symbols, end_offset = _collect_piano_hands(score)
    violin_two_events, cello_events = _upper_and_bass_for_rules(
        treble, bass, meter_key, chord_symbols, end_offset, apply_rules, "Violin II"
    )
    violin_one = _quartet_part("Violin I", clef.TrebleClef(), treble, meter_key, False)
    violin_two = _quartet_part("Violin II", clef.TrebleClef(), violin_two_events, meter_key, False)
    viola = _quartet_part("Viola", clef.AltoClef(), bass, meter_key, True)
    cello = _quartet_part("Cello", clef.BassClef(), cello_events, meter_key, False)
    _replace_with_quartet(score, (violin_one, violin_two, viola, cello))


def _quarter_aligned(value: float) -> bool:
    return abs(value - round(value)) < 0.02


def _time_signature_labels(score: stream.Score) -> List[str]:
    labels = []
    for part in score.parts:
        for time_sig in part.recurse().getElementsByClass(meter.TimeSignature):
            labels.append(time_sig.ratioString)
    if not labels:
        for time_sig in score.recurse().getElementsByClass(meter.TimeSignature):
            labels.append(time_sig.ratioString)
    return labels


def _beat_bars_from_measures(part) -> Optional[List[Tuple[float, float, float, float]]]:
    """Each bar as (offset, written length, padding at the start, padding at the end)."""
    bars = []
    for measure in part.getElementsByClass(stream.Measure):
        length = round(float(measure.quarterLength), 5)
        pad_left = round(float(getattr(measure, "paddingLeft", 0) or 0), 5)
        pad_right = round(float(getattr(measure, "paddingRight", 0) or 0), 5)
        covered = length + pad_left + pad_right
        if abs(covered - 4.0) > 0.05:
            print("[beat] A bar is not 4 beats long. Skipping the beat.")
            return None
        if not (_quarter_aligned(length) and _quarter_aligned(pad_left) and _quarter_aligned(pad_right)):
            print("[beat] A bar cuts through a beat. Skipping the beat.")
            return None
        window_end = pad_left + length
        for beat in range(4):
            start = float(beat)
            stop = start + 1.0
            overlaps = stop > pad_left + 1e-4 and start < window_end - 1e-4
            inside = start >= pad_left - 1e-4 and stop <= window_end + 1e-4
            if overlaps and not inside:
                print("[beat] A bar cuts through a beat. Skipping the beat.")
                return None
        bars.append((round(float(measure.offset), 5), length, pad_left, pad_right))
    return bars


def _beat_bars_from_length(score: stream.Score) -> Optional[List[Tuple[float, float, float, float]]]:
    """Full 4-beat bars from the start, when the file has no measures to follow."""
    end = 0.0
    for part in score.parts:
        end = max(end, float(part.highestTime))
    if end <= 0:
        end = float(score.highestTime)
    full_bars = int((end + 1e-3) // 4)
    if full_bars < 1:
        print("[beat] The file is shorter than one 4/4 bar. Skipping the beat.")
        return None
    if end - full_bars * 4 > 0.05:
        print("[beat] The last incomplete bar is left without a beat.")
    return [(float(index * 4), 4.0, 0.0, 0.0) for index in range(full_bars)]


def _prepare_simple_beat(score: stream.Score) -> Optional[List[Tuple[float, float, float, float]]]:
    """Bar map for the metronome. None means the beat stays off, and a reason was printed."""
    labels = _time_signature_labels(score)
    if not labels:
        print("[beat] No time signature found. The beat only runs in 4/4.")
        return None
    others = sorted({label for label in labels if label != "4/4"})
    if others:
        print(f"[beat] Time signature is {others[0]}. The beat only runs in 4/4.")
        return None
    source = None
    source_count = 0
    for part in score.parts:
        count = len(list(part.getElementsByClass(stream.Measure)))
        if count > source_count:
            source = part
            source_count = count
    if source is not None:
        return _beat_bars_from_measures(source)
    return _beat_bars_from_length(score)


def _beat_voices(pad_left: float, length: float):
    """Kick on beats 1 and 3, snare on 2 and 4, hi-hat on every eighth.

    The written window can be shorter than 4 when the bar is a pickup or is
    cut off at the end. Beats outside that window are left out.
    """
    low = stream.Voice(id="1")
    hats = stream.Voice(id="2")
    window_end = pad_left + length
    for beat in range(4):
        start = float(beat)
        if start < pad_left - 1e-4 or start + 1 > window_end + 1e-4:
            continue
        drum = note.Note("F4" if beat % 2 == 0 else "B4", quarterLength=1)
        drum.stemDirection = "down"
        low.append(drum)
        for _ in range(2):
            hat = note.Note("F5", quarterLength=0.5)
            hat.stemDirection = "up"
            hats.append(hat)
    if not low.notesAndRests and length > 0:
        low.append(note.Rest(quarterLength=length))
        hats.append(note.Rest(quarterLength=length))
    return low, hats


def _write_simple_beat(score: stream.Score, bars: List[Tuple[float, float, float, float]]) -> None:
    """Add one Beat part. The other parts are left as they are."""
    part = stream.Part()
    part.partName = "Beat"
    part.partAbbreviation = "Bt."
    drums = instrument.Instrument()
    drums.instrumentName = "Drums"
    drums.partName = "Beat"
    drums.midiChannel = 9
    first = True
    for number, (offset, length, pad_left, pad_right) in enumerate(bars, start=1):
        measure = stream.Measure(number=number)
        measure.paddingLeft = pad_left
        measure.paddingRight = pad_right
        if first:
            measure.insert(0, drums)
            measure.insert(0, clef.PercussionClef())
            measure.insert(0, meter.TimeSignature("4/4"))
            first = False
        low, hats = _beat_voices(pad_left, length)
        measure.insert(0, low)
        measure.insert(0, hats)
        part.insert(offset, measure)
    score.insert(0, part)
    print(
        f"[beat] Added a 4/4 beat for {len(bars)} bar(s). "
        "Kick is F4, snare is B4, hi-hat is F5."
    )


def add_simple_beat(score: stream.Score) -> None:
    """Add a metronome part: kick on 1 and 3, snare on 2 and 4, eighth-note hi-hats.

    This runs only when that checkbox is on, and only when every time signature
    in the file is 4/4. The notes are ordinary pitches on a percussion staff
    (F4, B4, F5) so they can be dragged onto whatever drum sound is loaded.
    """
    bars = _prepare_simple_beat(score)
    if bars:
        _write_simple_beat(score, bars)


def piano_to_woodwind_quartet(score: stream.Score, apply_rules: bool = False) -> None:
    """Replace the piano staves with Flute, Oboe, Clarinet, and Bassoon.

    This runs only when that checkbox is on. Flute and oboe receive the treble-clef
    notes, so they can match. Clarinet and bassoon receive the bass-clef notes.
    The clarinet is written an octave higher, on the treble clef. The bassoon stays
    in bass. Parts are written at concert pitch.

    The rules checkbox is separate. It simplifies the bassoon to beat 1 and beat 3,
    and it turns the oboe into eighth-note arpeggios of the chord names.
    """
    treble, bass, meter_key, chord_symbols, end_offset = _collect_piano_hands(score)
    oboe_events, bassoon_events = _upper_and_bass_for_rules(
        treble, bass, meter_key, chord_symbols, end_offset, apply_rules, "Oboe"
    )
    flute = _quartet_part("Flute", clef.TrebleClef(), treble, meter_key, False)
    oboe = _quartet_part("Oboe", clef.TrebleClef(), oboe_events, meter_key, False)
    clarinet = _quartet_part("Clarinet", clef.TrebleClef(), bass, meter_key, True)
    bassoon = _quartet_part("Bassoon", clef.BassClef(), bassoon_events, meter_key, False)
    _replace_with_quartet(score, (flute, oboe, clarinet, bassoon))


def manipulate_musicxml(
    input_path: str,
    output_path: str,
    min_pitch: Optional[int] = None,
    merge_parts_flag: bool = False,
    remove_unisons_flag: bool = False,
    remove_redundant_pitch_classes_flag: bool = False,
    quantize: Optional[str] = None,
    add_text: Optional[str] = None,
    text_type: str = "expression",
    text_pitch: Optional[int] = None,
    text_offset: Optional[float] = None,
    auto_number: bool = False,
    auto_number_mode: str = "string",
    sibelius_fingering: bool = False,
    fingering_octave_lower: bool = False,
    tab_octave_lower: bool = False,
    retrograde_pitches: bool = False,
    retrograde_rhythms: bool = False,
    retrograde_both: bool = False,
    randomize_rhythms: bool = False,
    add_guitar_tab_flag: bool = False,
    string_quartet_flag: bool = False,
    string_quartet_rules_flag: bool = False,
    woodwind_quartet_flag: bool = False,
    woodwind_quartet_rules_flag: bool = False,
    simple_beat_flag: bool = False,
    lan_four_measures_per_system_flag: bool = False,
    lan_five_systems_per_page_flag: bool = False,
) -> None:
    score = load_score(input_path)
    beat_bars = _prepare_simple_beat(score) if simple_beat_flag else None
    if woodwind_quartet_flag and string_quartet_flag:
        print("[quartet] Both quartet boxes are checked. Using the woodwind quartet.")
    if woodwind_quartet_flag:
        piano_to_woodwind_quartet(score, apply_rules=woodwind_quartet_rules_flag)
    elif string_quartet_flag:
        piano_to_string_quartet(score, apply_rules=string_quartet_rules_flag)
    if merge_parts_flag:
        score = merge_parts(score)
    if min_pitch is not None:
        lift_notes_below_pitch(score, min_pitch=min_pitch)
    if remove_unisons_flag:
        remove_unison_notes(score)
    if remove_redundant_pitch_classes_flag:
        remove_redundant_pitch_classes(score)
    if quantize:
        if quantize.lower() not in GRID_MAP:
            raise ValueError(f"Invalid quantize value: {quantize}. Use: {list(GRID_MAP.keys())}")
        quantize_score(score, quantize.lower())
    apply_retrograde_and_rhythm(
        score,
        retrograde_pitches=retrograde_pitches,
        retrograde_rhythms=retrograde_rhythms,
        retrograde_both=retrograde_both,
        randomize_rhythms=randomize_rhythms,
    )
    if add_text:
        if text_pitch is not None:
            add_text_by_pitch(score, text_pitch, add_text, text_type)
        elif text_offset is not None:
            add_text_by_rhythm(score, text_offset, add_text, text_type)
        else:
            add_text_to_notes(score, text_type=text_type, text=add_text)
    if add_guitar_tab_flag:
        add_guitar_tab(score, tab_octave_lower=tab_octave_lower)
    if auto_number:
        add_auto_number_annotations(
            score,
            mode=auto_number_mode,
            sibelius_fingering=sibelius_fingering,
            fingering_octave_lower=fingering_octave_lower,
        )
        _strip_fingering_from_tab_parts(score)
    if simple_beat_flag and beat_bars:
        timing_changed = bool(quantize or retrograde_pitches or retrograde_rhythms or retrograde_both or randomize_rhythms)
        if timing_changed:
            add_simple_beat(score)
        else:
            _write_simple_beat(score, beat_bars)
    if lan_four_measures_per_system_flag or lan_five_systems_per_page_flag:
        apply_lan_score_layout(
            score,
            four_measures_per_system=lan_four_measures_per_system_flag,
            five_systems_per_page=lan_five_systems_per_page_flag,
        )
    save_score(score, output_path)


# --- Menu constants and path helpers (handle spaces and quoted paths) ---
QUANTIZE_CHOICES = ["whole", "half", "quarter", "eighth", "sixteenth", "thirtysecond"]
AUTO_NUMBER_MODES = ["string", "finger"]
TEXT_TYPES = ["lyric", "expression", "fingering", "articulation"]


def strip_path(s: str) -> str:
    """Strip whitespace and surrounding quotes so paths with spaces work when pasted."""
    s = s.strip()
    if len(s) >= 2 and s[0] == s[-1] and s[0] in "\"'":
        s = s[1:-1].strip()
    return s


def prompt(prompt_text: str, default: str = "") -> str:
    if default:
        result = input(f"{prompt_text} [{default}]: ").strip()
        return strip_path(result) if result else default
    return strip_path(input(f"{prompt_text}: ").strip())


def prompt_int(prompt_text: str, default: Optional[int] = None) -> Optional[int]:
    while True:
        raw = prompt(prompt_text, str(default) if default is not None else "")
        if not raw:
            return default
        try:
            return int(raw)
        except ValueError:
            print("  Please enter a number (e.g. 40 for E2), or leave blank for none.")


def prompt_float(prompt_text: str, default: Optional[float] = None) -> Optional[float]:
    while True:
        raw = prompt(prompt_text, str(default) if default is not None else "")
        if not raw:
            return default
        try:
            return float(raw)
        except ValueError:
            print("  Please enter a number (e.g. 0.0 for first beat), or leave blank for none.")


def main_menu() -> None:
    print()
    print("=" * 60)
    print("  MusicXML Manipulator - Menu")
    print("=" * 60)
    print()
    print("  How it works: Enter input and output MusicXML paths, then choose")
    print("  options (1–7). Option 8 runs processing; 0 quits. You can type")
    print("  several numbers at once (e.g. 1 3 5 8 or 1,3,5,8).")
    print("  Paths with spaces are fine — paste or type the full path.")
    print()

    input_path = prompt("Input MusicXML file path")
    if not input_path:
        print("No input file given. Exiting.")
        return
    if not os.path.isfile(input_path):
        print(f"File not found: {input_path}")
        return
    base, _ = os.path.splitext(input_path)
    default_out = base + "_processed.musicxml"
    output_path = strip_path(prompt("Output MusicXML file path", default_out))
    if not output_path:
        print("No output file given. Exiting.")
        return

    merge_parts = False
    min_pitch: Optional[int] = None
    remove_unisons = False
    remove_redundant_pitch_classes = False
    quantize: Optional[str] = None
    add_text: Optional[str] = None
    text_type = "expression"
    text_pitch: Optional[int] = None
    text_offset: Optional[float] = None
    auto_number = False
    auto_number_mode = "string"

    while True:
        print()
        print("-" * 60)
        print("  Current settings")
        print("-" * 60)
        print(f"  1. Merge all parts into one      : {'Yes' if merge_parts else 'No'}")
        print(f"  2. Min pitch (raise notes below) : {min_pitch if min_pitch is not None else 'Off'}")
        print(f"  3. Remove unison duplicates      : {'Yes' if remove_unisons else 'No'}")
        print(f"  4. Remove redundant pitch classes : {'Yes' if remove_redundant_pitch_classes else 'No'}")
        print(f"  5. Quantize timing               : {quantize or 'Off'}")
        print(f"  6. Add text annotations          : {add_text or 'Off'}")
        if add_text:
            print(f"     Type / pitch / offset          : {text_type} / {text_pitch} / {text_offset}")
        print(f"  7. Auto-number (guitar labels)   : {'Yes' if auto_number else 'No'}")
        if auto_number:
            print(f"     Mode                          : {auto_number_mode}")
        print("-" * 60)
        print("  8. Process MusicXML (run with above settings)")
        print("  0. Quit (no processing)")
        print("  You can enter several at once, e.g.  1 3 5 8  or  1,3,5,8")
        print()

        raw = prompt("Choose 1–8 or 0", "8").strip().lower()
        choices = [c for part in raw.replace(",", " ").split() for c in part if c in "012345678"]
        if not choices:
            choices = ["8"]

        for choice in choices:
            if choice == "0":
                print("Exiting.")
                return
            if choice == "1":
                merge_parts = not merge_parts
                print(f"  Merge parts is now: {'Yes' if merge_parts else 'No'}")
            elif choice == "2":
                print("  Min pitch: notes below this MIDI note are raised by octaves.")
                print("  Example: 40 = E2 (low E on guitar). Leave blank to turn off.")
                min_pitch = prompt_int("  Min pitch (0–127)", min_pitch)
            elif choice == "3":
                remove_unisons = not remove_unisons
                print(f"  Remove unisons is now: {'Yes' if remove_unisons else 'No'}")
            elif choice == "4":
                remove_redundant_pitch_classes = not remove_redundant_pitch_classes
                print(f"  Remove redundant pitch classes is now: {'Yes' if remove_redundant_pitch_classes else 'No'}")
            elif choice == "5":
                if quantize:
                    quantize = None
                    print("  Quantize is now: Off")
                else:
                    q = prompt("  Quantize grid (" + ", ".join(QUANTIZE_CHOICES) + ")", "sixteenth").strip().lower()
                    quantize = q if q in QUANTIZE_CHOICES else None
                    print(f"  Quantize is now: {quantize or 'Off'}")
            elif choice == "6":
                if add_text:
                    add_text = None
                    text_pitch = None
                    text_offset = None
                    print("  Add text is now: Off")
                else:
                    add_text = prompt("  Text to add (e.g. 'con fuoco', 'la', '1')", "con fuoco").strip() or "con fuoco"
                    print("  Types: " + ", ".join(TEXT_TYPES))
                    tt = prompt("  Text type", text_type).strip().lower()
                    if tt in TEXT_TYPES:
                        text_type = tt
                    text_pitch = prompt_int("  Only at MIDI pitch (blank = all notes)", None)
                    text_offset = prompt_float("  Only at offset in quarter notes (blank = all)", None)
                    print(f"  Add text is now: '{add_text}' (type={text_type})")
            elif choice == "7":
                auto_number = not auto_number
                if auto_number:
                    print("  Mode: 'string' = string numbers 6–1, 'finger' = 0=open, 1–4 fretted")
                    m = prompt("  Auto-number mode", auto_number_mode).strip().lower()
                    if m in AUTO_NUMBER_MODES:
                        auto_number_mode = m
                    print(f"  Auto-number is now: Yes (mode={auto_number_mode})")
                else:
                    print("  Auto-number is now: No")
            elif choice == "8":
                print()
                print("Processing...")
                try:
                    manipulate_musicxml(
                        input_path=os.path.abspath(input_path),
                        output_path=os.path.abspath(output_path),
                        min_pitch=min_pitch,
                        merge_parts_flag=merge_parts,
                        remove_unisons_flag=remove_unisons,
                        remove_redundant_pitch_classes_flag=remove_redundant_pitch_classes,
                        quantize=quantize,
                        add_text=add_text,
                        text_type=text_type,
                        text_pitch=text_pitch,
                        text_offset=text_offset,
                        auto_number=auto_number,
                        auto_number_mode=auto_number_mode,
                    )
                    print(f"[+] Processed MusicXML saved to: {output_path}")
                except Exception as e:
                    print(f"[!] Error: {e}")
                return


def run_cli() -> None:
    parser = argparse.ArgumentParser(
        description="MusicXML Manipulator - Merge parts, lift pitch, remove unisons, remove redundant pitch classes, quantize, add text, auto-number.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--input", "-i", required=True, help="Input MusicXML file path")
    parser.add_argument("--output", "-o", required=True, help="Output MusicXML file path")
    parser.add_argument("--min-pitch", type=int, default=None, help="Min MIDI pitch; notes below raised by octaves (e.g. 40 = E2)")
    parser.add_argument("--merge-parts", action="store_true", help="Merge all parts into one")
    parser.add_argument("--remove-unisons", action="store_true", help="Remove unison duplicates")
    parser.add_argument("--remove-redundant-pitch-classes", action="store_true", help="Remove redundant note names in chords")
    parser.add_argument("--quantize", type=str, choices=list(GRID_MAP.keys()), default=None, help="Quantize to grid")
    parser.add_argument("--add-text", type=str, default=None, help="Add text to notes")
    parser.add_argument("--text-type", type=str, choices=TEXT_TYPES, default="expression", help="lyric, expression, fingering, articulation")
    parser.add_argument("--text-pitch", type=int, default=None, help="Only add text to this MIDI pitch")
    parser.add_argument("--text-offset", type=float, default=None, help="Only add text at this offset (quarter notes)")
    parser.add_argument("--auto-number", action="store_true", help="Add guitar string/finger labels")
    parser.add_argument("--auto-number-mode", type=str, choices=AUTO_NUMBER_MODES, default="string", help="string or finger")
    args = parser.parse_args()
    input_path = strip_path(os.path.abspath(args.input))
    output_path = strip_path(os.path.abspath(args.output))
    manipulate_musicxml(
        input_path=input_path,
        output_path=output_path,
        min_pitch=args.min_pitch,
        merge_parts_flag=args.merge_parts,
        remove_unisons_flag=args.remove_unisons,
        remove_redundant_pitch_classes_flag=args.remove_redundant_pitch_classes,
        quantize=args.quantize,
        add_text=args.add_text,
        text_type=args.text_type,
        text_pitch=args.text_pitch,
        text_offset=args.text_offset,
        auto_number=args.auto_number,
        auto_number_mode=args.auto_number_mode,
    )
    print(f"[+] Processed MusicXML saved to: {output_path}")


if __name__ == "__main__":
    if len(sys.argv) > 1:
        run_cli()
    else:
        main_menu()
