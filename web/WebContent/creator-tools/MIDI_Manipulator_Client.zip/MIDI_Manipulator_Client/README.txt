MIDI Manipulator Client
=======================

This folder is the whole tool. You use it in a browser on your own computer.
You do not need to edit any of the files.


1. Install Python once
-----------------------

Download Python 3 from https://www.python.org/downloads/ and install it.

On Windows, the installer has a checkbox that says "Add python.exe to PATH".
Turn that on, then click Install.

On a Mac, open the downloaded installer and click through it. If a newer
Python is already installed, you can skip this step.


2. An editor is optional
------------------------

An editor such as Visual Studio Code is useful if you later want to read or
change the scripts. It is recommended for that, and it is not required to
use this tool. You can skip it and go straight to the next step.


3. Start the page
------------------

On a Mac, double-click:

    Start MIDI Manipulator.command

On Windows, double-click:

    Start MIDI Manipulator.bat

The first time, that starter installs the libraries listed in
requirements.txt. That can take a few minutes. Leave the window open.
When it is ready, your browser opens to the page.

Later starts are quicker. Keep the starter window open while you work.
Closing that window stops the page. Double-click the starter again to
bring it back.


4. Use it
---------

Choose a .mid, .musicxml, .xml, or .mxl file, check the boxes you want,
and click Process and download. The result saves through your browser.

The short-video box needs ffmpeg installed separately. The music tools
do not.


If the starter says Python was not found
-----------------------------------------

Finish step 1, quit the starter window, and double-click it again.
