#!/usr/bin/env python3
"""
XML MIDI Manipulator. The client package.

A separate copy of the private page, packaged so another person can run it
on their own computer. The original scripts and the private page are not
this file. This folder holds its own copies of the engines.

Double-click "Start MIDI Manipulator" in this folder. That starter installs
the libraries and opens a browser to this page on this computer only.
"""

import importlib.util
import io
import json
import os
import random
import re
import shutil
import socket
import subprocess
import tempfile
import threading
import traceback
import webbrowser
from datetime import datetime

from flask import Flask, request, send_file

_HERE = os.path.dirname(os.path.abspath(__file__))
MIDI_PATH = os.environ.get(
    "MIDI_MANIPULATOR_PATH",
    os.path.join(_HERE, "MIDI_manipulator_engine.py"),
)
XML_PATH = os.environ.get(
    "MIDI_XML_MANIPULATOR_PATH",
    os.path.join(_HERE, "MIDI_manipulator_musicxml_engine.py"),
)
HOST = os.environ.get("MIDI_CLIENT_HOST", "127.0.0.1")
PORT = int(os.environ.get("MIDI_CLIENT_PORT", "5013"))
BG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "midi_manipulator_bg.jpg")
MAX_BYTES = int(os.environ.get("MIDI_LAN_MAX_BYTES", str(20 * 1024 * 1024)))
VIDEO_MAX_BYTES = int(os.environ.get("MIDI_LAN_VIDEO_MAX_BYTES", str(500 * 1024 * 1024)))
SHORT_SECONDS = 59.0
SHORT_MAX_SPEED = 16.0

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = VIDEO_MAX_BYTES
_modules = {}


def _load(key: str, path: str):
    if key in _modules:
        return _modules[key]
    if not os.path.isfile(path):
        raise FileNotFoundError(path)
    spec = importlib.util.spec_from_file_location(key, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    _modules[key] = module
    return module


PAGE = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>XML MIDI Manipulator</title>
  <style>
    html { min-height: 100%; }
    body {
      font-family: Georgia, serif;
      color: #f2f2f2;
      margin: 0;
      min-height: 100vh;
      background: #120c09;
    }
    body::before {
      content: "";
      position: fixed;
      inset: 0;
      z-index: -1;
      background:
        linear-gradient(180deg, rgba(10, 7, 5, 0.42) 0%, rgba(10, 7, 5, 0.58) 100%),
        url("/background.jpg") center / cover no-repeat;
    }
    main { position: relative; max-width: 42rem; margin: 2rem auto; padding: 0 1rem 3rem; }
    h1 { font-size: 1.6rem; text-shadow: 0 1px 12px rgba(0, 0, 0, 0.65); }
    p.note { color: #c8c8c8; }
    label { display: block; margin: 0.7rem 0; }
    .sub { margin-left: 1.5rem; }
    fieldset { border: 1px solid #555; margin: 1rem 0; padding: 0.6rem 1rem 1rem; }
    button { background: #2f6f4e; color: white; border: 0; padding: 0.8rem 1.1rem; font-size: 1rem; cursor: pointer; }
    input[type="number"], input[type="text"], select { background: #111; color: #fff; border: 1px solid #666; padding: 0.3rem; }
    .err { color: #ffb4b4; white-space: pre-wrap; }
    .ico { display: inline-block; width: 1.05rem; height: 1.05rem; vertical-align: -0.18rem; margin: 0 0.28rem 0 0.12rem; }
    .ico svg { display: block; width: 100%; height: 100%; stroke: currentColor; fill: none; stroke-width: 1.6; stroke-linecap: round; stroke-linejoin: round; }
    .ico.gold { color: #e7c36a; }
    .ico.teal { color: #7dcaa8; }
    .ico.amber { color: #f0a35e; }
    .ico.coral { color: #ff8f7a; }
    .ico.sky { color: #8ec5ff; }
    .ico.violet { color: #c9a6ff; }
    .ico.dots svg { fill: currentColor; stroke: none; }
    .emo { display: inline-block; margin: 0 0.28rem 0 0.08rem; padding: 0 0.18rem; border-radius: 0.35rem; line-height: 1.35; }
    .emo.gold { background: rgba(231, 195, 106, 0.28); }
    .emo.teal { background: rgba(125, 202, 168, 0.28); }
    .emo.amber { background: rgba(240, 163, 94, 0.28); }
    .emo.coral { background: rgba(255, 143, 122, 0.28); }
    .emo.sky { background: rgba(142, 197, 255, 0.28); }
    .emo.violet { background: rgba(201, 166, 255, 0.28); }
    .emo.rose { background: rgba(232, 160, 191, 0.32); }
    .emo.green { background: rgba(126, 196, 122, 0.28); }
    fieldset.sec {
      border-radius: 12px;
      background: rgba(14, 11, 9, 0.78);
      backdrop-filter: blur(3px);
      padding: 0.4rem 1rem 0.8rem;
    }
    fieldset.sec legend {
      padding: 0 0.4rem;
      font-size: 1.08rem;
      background: rgba(14, 11, 9, 0.88);
      border-radius: 8px;
    }
    fieldset.clean { border-color: #666; }
    fieldset.guitar { border-color: rgba(126, 196, 122, 0.7); }
    fieldset.midi { border-color: rgba(231, 195, 106, 0.85); background: rgba(26, 20, 12, 0.8); }
    fieldset.rhythm { border-color: rgba(255, 143, 122, 0.75); }
    fieldset.ensemble { border-color: rgba(232, 160, 191, 0.7); }
    fieldset.score { border-color: rgba(142, 197, 255, 0.65); }
    fieldset.short { border-color: rgba(240, 163, 94, 0.8); }
    .group-title { margin: 0.9rem 0 0.15rem; font-size: 0.98rem; }
    .pair { display: grid; grid-template-columns: 1fr 1fr; gap: 0.35rem 1rem; align-items: start; }
    .pair label { margin: 0.35rem 0; }
    .arrow { margin: 0 0.2rem; color: #e7c36a; }
    button { width: 100%; border-radius: 10px; margin-top: 0.4rem; }
  </style>
</head>
<body>
<main>
  <h1>XML MIDI Manipulator</h1>
  <p class="note">This page runs on your computer. Sheet-music editors start with a MusicXML file. Producers start with a .mid file. Choose a file, check the boxes you want, then download the result. A .mid file keeps every track unless you check Merge. A .musicxml / .xml / .mxl file uses the score tools. The gold box is only for .mid files.</p>
  <form action="/process" method="post" enctype="multipart/form-data">
    <label>File (.mid, .musicxml, .xml, .mxl)
      <input type="file" name="midi" accept=".mid,.midi,.xml,.musicxml,.mxl" required>
    </label>
    <fieldset class="sec clean">
      <legend>Cleaning</legend>
      <label><input type="checkbox" name="merge_tracks"> <span class="emo sky">🔗</span> Merge all tracks / parts into one</label>
      <label><input type="checkbox" name="remove_unisons"> <span class="emo amber">🟰</span> Remove unison duplicates</label>
      <label><input type="checkbox" name="remove_redundant_pitch_classes"> <span class="emo amber">🎼</span> Remove redundant pitch classes</label>
    </fieldset>
    <fieldset class="sec guitar">
      <legend><span class="emo green">🎸</span> Guitar</legend>
      <label><input type="checkbox" name="guitar_range"> <span class="emo green">🎹</span><span class="arrow">→</span><span class="emo green">🎸</span> Force into Guitar Range</label>
      <label><input type="checkbox" name="add_guitar_tab"> <span class="emo green">🎸</span> Add GTR TAB</label>
      <div class="pair">
        <label><input type="checkbox" name="tab_octave_lower"> <span class="emo green">⏬</span> Envision the tabs an octave lower.</label>
        <label><input type="checkbox" name="fingering_octave_lower"> <span class="emo violet">⏬</span> Envision the fingering being an octave lower.</label>
      </div>
      <p class="note">For vocal scores written an octave high without an octave-transposing clef. Tabs go with Add GTR TAB. Fingering goes with Auto-number.</p>
      <label><input type="checkbox" name="auto_number"> <span class="emo violet">🔢</span> Auto-number</label>
      <label>Auto-number mode
        <select name="auto_number_mode">
          <option value="finger">finger</option>
          <option value="string">string</option>
        </select>
      </label>
      <label><input type="checkbox" name="sibelius_fingering"> <span class="emo violet">✋</span> Try to use fingerings as Sibelius's fingering text</label>
    </fieldset>
    <fieldset class="sec midi">
      <legend><span class="emo gold">🎵</span> MIDI</legend>
      <p class="note">Tempo and controllers. These change a .mid file. A MusicXML file skips this box.</p>
      <label><input type="checkbox" name="rubato_four_bar"> <span class="emo gold">🎵</span><span class="ico gold" title="Tempo"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M5 14h6M8 14V3M8 3l4 9"/></svg></span> 4-bar rubato. Bars 1 and 4 drop 8 BPM on the tempo lane; bars 2 and 3 stay at the song tempo.</label>
      <label><input type="checkbox" name="humanize_cc"> <span class="emo teal">〰️</span><span class="ico teal" title="Modulation and expression"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M1 8c1.6-3.2 2.6-3.2 4.2 0s2.6 3.2 4.2 0 2.6-3.2 4.2 0"/></svg></span> Humanize modulation and expression. A 4-bar ebb and flow around the middle of the range, with a little chaos. Volume and velocity stay as they are.</label>
      <label><input type="checkbox" name="humanize_cc_custom"> <span class="emo amber">🎛️</span><span class="ico amber" title="Chosen controller"><svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="5"/><path d="M8 8l3-2"/></svg></span> Humanize one other controller with that same 4-bar wave.</label>
      <label class="sub">CC number
        <input type="number" name="humanize_cc_number" min="0" max="127" step="1" placeholder="74">
      </label>
      <p class="note sub">For a specialized instrument, type the controller number from its manual. Volume is 7, so leave this blank unless you want that rewritten too.</p>
    </fieldset>
    <fieldset class="sec rhythm">
      <legend><span class="emo coral">🥁</span> Rhythm</legend>
      <p class="note">How the notes sit in time. Leave Quantize on Off unless you want them snapped to a grid.</p>
      <label><span class="emo sky">📏</span> Quantize
        <select name="quantize">
          <option value="">Off</option>
          <option>whole</option>
          <option>half</option>
          <option>quarter</option>
          <option>eighth</option>
          <option>sixteenth</option>
          <option>thirtysecond</option>
        </select>
      </label>
      <label><input type="checkbox" name="simple_beat"> <span class="emo coral">🥁</span><span class="ico coral dots" title="Beat"><svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="3" cy="11" r="1.5"/><circle cx="7" cy="6" r="1.5"/><circle cx="11" cy="11" r="1.5"/><circle cx="14" cy="6" r="1.3"/></svg></span> Add a simple 4/4 beat?</label>
      <p class="note">Kick on 1 and 3, snare on 2 and 4, eighth-note hi-hats. Only runs in 4/4. Written as F4, B4, and F5, so the notes can be dragged onto a drum sound.</p>
      <label><input type="checkbox" name="retrograde_pitches"> <span class="emo sky">🔄</span><span class="ico sky" title="Pitches backward"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M13 5H4M7 2L4 5l3 3M4 11h8"/></svg></span> Retrograde pitches</label>
      <label><input type="checkbox" name="retrograde_rhythms"> <span class="emo sky">🔁</span><span class="ico sky" title="Rhythm backward"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M13 8H3M6 5L3 8l3 3"/></svg></span> Retrograde rhythms</label>
      <label><input type="checkbox" name="retrograde_both"> <span class="emo sky">↩️</span><span class="ico sky" title="Both backward"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M13 4H4M6 2L4 4l2 2M13 12H4M6 10l-2 2 2 2"/></svg></span> Retrograde both</label>
      <label><input type="checkbox" name="randomize_rhythms"> <span class="emo violet">🎲</span><span class="ico violet" title="Rhythm lengths"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 13V8M7 13V4M11 13V9M14 13V6"/></svg></span> Randomize rhythm lengths (16th note through 4 beats, one tie, one dot)</label>
    </fieldset>
    <fieldset class="sec ensemble">
      <legend>Ensembles</legend>
      <p class="group-title"><span class="emo rose">🎻</span> String quartet</p>
      <label><input type="checkbox" name="string_quartet"> <span class="emo rose">🎻</span> Turn piano into string quartet?</label>
      <label class="sub"><input type="checkbox" name="string_quartet_rules"> <span class="emo rose">🎻</span> apply string quartet rules:</label>
      <p class="note sub">Rule 1: Cello only gets two notes, from beat 1 and beat 3 (simplified cello).</p>
      <p class="note sub">Rule 2: Violin II spells out the chord name with 8th-note arpeggios when the score has chord names.</p>
      <p class="group-title"><span class="emo teal">🎷</span> Woodwind quartet</p>
      <label><input type="checkbox" name="woodwind_quartet"> <span class="emo teal">🎷</span> Turn piano into woodwind quartet?</label>
      <label class="sub"><input type="checkbox" name="woodwind_quartet_rules"> <span class="emo teal">🎷</span> apply woodwind quartet rules:</label>
      <p class="note sub">Rule 1: Bassoon only gets two notes, from beat 1 and beat 3 (simplified bassoon).</p>
      <p class="note sub">Rule 2: Oboe spells out the chord name with 8th-note arpeggios when the score has chord names.</p>
    </fieldset>
    <fieldset class="sec score">
      <legend><span class="emo sky">📄</span> Score</legend>
      <p class="note">Layout and words. These apply to MusicXML. A .mid file ignores this box.</p>
      <label><input type="checkbox" name="lan_four_measures_per_system"> <span class="emo sky">📄</span> Four measures per system</label>
      <label><input type="checkbox" name="lan_five_systems_per_page"> <span class="emo sky">📚</span> Five systems per page</label>
      <p class="note">Hints for Sibelius. Best with both checked. Sibelius may still reflow on import.</p>
      <label><span class="emo gold">✏️</span> Add text
        <input type="text" name="add_text" placeholder="optional">
      </label>
      <label>Text type
        <select name="text_type">
          <option>expression</option>
          <option>lyric</option>
          <option>fingering</option>
          <option>articulation</option>
        </select>
      </label>
      <label>Only this MIDI pitch (blank = all notes)
        <input type="number" name="text_pitch" min="0" max="127" step="1">
      </label>
      <label>Only this beat offset in quarter notes (blank = all)
        <input type="text" name="text_offset" placeholder="optional, e.g. 0 or 1.5">
      </label>
    </fieldset>
    <button type="submit">Process and download</button>
  </form>
  <form action="/short-video" method="post" enctype="multipart/form-data">
    <fieldset class="sec short">
      <legend><span class="emo amber">📱</span> Short video</legend>
      <p class="note">Experimental. A wide video becomes a vertical 9:16 clip under 60 seconds. The picture sweeps from left to right so the sides are not simply cut off, and silent stretches are left out.</p>
      <label>Video (.mp4, .mov, .mkv, .webm)
        <input type="file" name="video" accept="video/*,.mp4,.mov,.m4v,.mkv,.webm" required>
      </label>
      <label><input type="checkbox" name="ken_burns" checked> <span class="emo amber">↔️</span> Sweep left to right</label>
      <label><input type="checkbox" name="skip_silence" checked> <span class="emo sky">🔇</span> Skip silence</label>
      <label><input type="checkbox" name="add_title"> <span class="emo gold">✏️</span> Add a title</label>
      <label class="sub">Title
        <input type="text" name="title_text" maxlength="80" placeholder="Shown across the top">
      </label>
      <button type="submit">Make a short</button>
    </fieldset>
  </form>
  <p class="err">__ERROR__</p>
</main>
</body>
</html>
"""


def _lan_ips():
    ips = []
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if ip and not ip.startswith("127."):
                ips.append(ip)
    except OSError:
        pass
    if not ips:
        try:
            probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            probe.connect(("192.168.1.1", 80))
            ips.append(probe.getsockname()[0])
            probe.close()
        except OSError:
            pass
    return sorted(set(ips))


def _checked(name: str) -> bool:
    return request.form.get(name) == "on"


def _optional_int(name: str):
    raw = (request.form.get(name) or "").strip()
    if not raw:
        return None
    value = int(raw)
    if value < 0 or value > 127:
        raise ValueError(f"{name} must be from 0 to 127.")
    return value


def _optional_float(name: str):
    raw = (request.form.get(name) or "").strip()
    if not raw:
        return None
    return float(raw)


def _apply_midi_track(
    mod,
    track,
    ticks_per_beat,
    min_pitch,
    remove_unisons,
    remove_redundant,
    quantize,
    auto_number,
    auto_mode,
    fingering_octave_lower,
):
    if min_pitch is not None:
        track = mod.lift_notes_below_pitch(track, min_pitch=min_pitch)
    if remove_unisons:
        track = mod.remove_unison_notes(track)
    if remove_redundant:
        track = mod.remove_redundant_pitch_classes(track)
    if quantize:
        quantize_map = {
            "whole": ticks_per_beat * 4,
            "half": ticks_per_beat * 2,
            "quarter": ticks_per_beat,
            "eighth": ticks_per_beat // 2,
            "sixteenth": ticks_per_beat // 4,
            "thirtysecond": ticks_per_beat // 8,
        }
        if quantize not in quantize_map:
            raise ValueError(f"Invalid quantize value: {quantize}")
        track = mod.quantize_track(track, ticks_per_beat, quantize_map[quantize])
    if auto_number:
        track = mod.add_auto_number_annotations(
            track,
            mode=auto_mode,
            fingering_octave_lower=fingering_octave_lower,
        )
    return track


def _midi_groups(track):
    abs_t = 0
    pending = {}
    notes = []
    for msg in track:
        abs_t += msg.time
        if msg.type == "note_on" and msg.velocity > 0:
            pending.setdefault((msg.channel, msg.note), []).append((abs_t, msg.velocity))
        elif msg.type == "note_off" or (msg.type == "note_on" and msg.velocity == 0):
            stack = pending.get((msg.channel, msg.note))
            if stack:
                start, vel = stack.pop(0)
                notes.append((start, abs_t, msg.note, vel, msg.channel))
    notes.sort()
    groups = []
    for item in notes:
        if groups and groups[-1][0][0] == item[0]:
            groups[-1].append(item)
        else:
            groups.append([item])
    return groups


def _rebuild_midi_notes(mod, track, groups):
    abs_t = 0
    prelude = []
    for msg in track:
        abs_t += msg.time
        if msg.type in ("note_on", "note_off"):
            continue
        if abs_t == 0:
            prelude.append(msg.copy(time=0))
    events = [(0, msg) for msg in prelude]
    for group in groups:
        for start, end, pitch, vel, ch in group:
            events.append((start, mod.Message("note_on", channel=ch, note=pitch, velocity=vel, time=0)))
            events.append((end, mod.Message("note_off", channel=ch, note=pitch, velocity=0, time=0)))
    events.sort(key=lambda item: (item[0], 0 if item[1].type == "note_off" else 1))
    new_track = mod.MidiTrack()
    prev = 0
    for when, msg in events:
        delta = max(0, int(when) - prev)
        prev = int(when)
        new_track.append(msg.copy(time=delta))
    return new_track


def _midi_bar_beats(track):
    for msg in track:
        if msg.type == "time_signature":
            return msg.numerator * (4.0 / msg.denominator)
    return 4.0


def _apply_midi_retrograde(mod, track, ticks_per_beat, opts):
    do_pitches = opts["retrograde_pitches"] or opts["retrograde_both"]
    do_rhythms = opts["retrograde_rhythms"] or opts["retrograde_both"]
    do_random = opts["randomize_rhythms"]
    if not (do_pitches or do_rhythms or do_random):
        return track
    groups = _midi_groups(track)
    if not groups:
        return track
    if do_pitches and do_rhythms:
        groups = list(reversed(groups))
    elif do_pitches:
        pitch_sets = [[item[2] for item in group] for group in groups]
        rewritten = []
        for group, pitches in zip(groups, reversed(pitch_sets)):
            start, end, _, vel, ch = group[0]
            rewritten.append([(start, end, pitch, vel, ch) for pitch in pitches])
        groups = rewritten
    if do_rhythms or do_random:
        if do_random:
            xml = _load("xml_master3", XML_PATH)
            bar = _midi_bar_beats(track)
            when_tick = 0
            durations = []
            for _ in groups:
                beat = when_tick / ticks_per_beat
                chosen = max(1, int(round(xml._random_rhythm_length(beat, bar) * ticks_per_beat)))
                durations.append(chosen)
                when_tick += chosen
        elif do_pitches and do_rhythms:
            durations = [max(1, group[0][1] - group[0][0]) for group in groups]
        else:
            durations = list(reversed([max(1, group[0][1] - group[0][0]) for group in groups]))
        when = min(group[0][0] for group in groups)
        packed = []
        for group, dur in zip(groups, durations):
            packed.append([(when, when + dur, pitch, vel, ch) for _, _, pitch, vel, ch in group])
            when += dur
        groups = packed
    return _rebuild_midi_notes(mod, track, groups)


def _add_midi_beat(mod, mid):
    """Channel 10 metronome. Same pitches as the MusicXML part: F4, B4, F5.

    The pattern starts at the beginning of the file and fills only complete
    groups of 4 beats. A MusicXML file follows the written bars instead.
    """
    signatures = []
    for track in mid.tracks:
        for msg in track:
            if msg.type == "time_signature":
                signatures.append((msg.numerator, msg.denominator))
    if not signatures:
        print("[beat] No time signature in the MIDI file. The beat only runs in 4/4.")
        return
    others = sorted({f"{num}/{den}" for num, den in signatures if not (num == 4 and den == 4)})
    if others:
        print(f"[beat] Time signature is {others[0]}. The beat only runs in 4/4.")
        return
    ticks = int(mid.ticks_per_beat)
    if ticks < 2:
        print("[beat] The MIDI file has no beat length to divide into eighths. Skipping the beat.")
        return
    end = 0
    for track in mid.tracks:
        abs_t = 0
        for msg in track:
            abs_t += msg.time
            if msg.type in ("note_on", "note_off"):
                end = max(end, abs_t)
    bar = ticks * 4
    full_bars = end // bar
    if full_bars < 1:
        print("[beat] The MIDI file is shorter than one 4/4 bar. Skipping the beat.")
        return
    if end - full_bars * bar > ticks // 4:
        print("[beat] The last incomplete bar is left without a beat.")
    kick, snare, hat = 65, 71, 77
    eighth = ticks // 2
    events = []
    for bar_index in range(full_bars):
        start = bar_index * bar
        for beat, pitch in ((0, kick), (1, snare), (2, kick), (3, snare)):
            when = start + beat * ticks
            events.append((when, "on", pitch))
            events.append((when + ticks, "off", pitch))
        for step in range(8):
            when = start + step * eighth
            events.append((when, "on", hat))
            events.append((when + eighth, "off", hat))
    events.sort(key=lambda item: (item[0], 0 if item[1] == "off" else 1, item[2]))
    beat = mod.MidiTrack()
    beat.append(mod.MetaMessage("track_name", name="Beat", time=0))
    beat.append(mod.MetaMessage(
        "time_signature",
        numerator=4,
        denominator=4,
        clocks_per_click=24,
        notated_32nd_notes_per_beat=8,
        time=0,
    ))
    prev = 0
    for when, kind, pitch in events:
        delta = int(when) - prev
        prev = int(when)
        if kind == "on":
            beat.append(mod.Message("note_on", channel=9, note=pitch, velocity=100, time=delta))
        else:
            beat.append(mod.Message("note_off", channel=9, note=pitch, velocity=0, time=delta))
    beat.append(mod.MetaMessage("end_of_track", time=0))
    mid.tracks.append(beat)
    print(
        f"[beat] Added a 4/4 beat for {full_bars} bar(s) on MIDI channel 10. "
        "Kick is F4, snare is B4, hi-hat is F5."
    )


def _process_midi(in_path, out_path, **opts):
    mod = _load("midi_master", MIDI_PATH)
    mid = mod.MidiFile(in_path)
    track_count = len(mid.tracks)
    if opts["merge"] and track_count > 1:
        mid = mod.merge_all_tracks(mid)
    new_mid = mod.MidiFile(ticks_per_beat=mid.ticks_per_beat)
    for track in mid.tracks:
        new_mid.tracks.append(
            _apply_midi_track(
                mod,
                track,
                mid.ticks_per_beat,
                opts["min_pitch"],
                opts["remove_unisons"],
                opts["remove_redundant"],
                opts["quantize"],
                opts["auto_number"],
                opts["auto_mode"],
                opts["fingering_octave_lower"],
            )
        )
        new_mid.tracks[-1] = _apply_midi_retrograde(mod, new_mid.tracks[-1], mid.ticks_per_beat, opts)
    if opts.get("simple_beat") and not opts.get("add_guitar_tab"):
        _add_midi_beat(mod, new_mid)
    if opts["rubato"]:
        mod.four_bar_rubato_midi(new_mid)
    chosen_cc = []
    if opts["humanize_cc"]:
        chosen_cc.extend([11, 1])
    if opts["humanize_cc_number"] is not None:
        chosen_cc.append(opts["humanize_cc_number"])
    if chosen_cc:
        mod.humanize_performance_cc(new_mid, controls=chosen_cc)
    new_mid.save(out_path)
    print(f"  MIDI tracks in={track_count} out={len(new_mid.tracks)} merge={opts['merge']} script={MIDI_PATH}")


def _process_xml(in_path, out_path, **opts):
    mod = _load("xml_master3", XML_PATH)
    mod.manipulate_musicxml(
        input_path=in_path,
        output_path=out_path,
        min_pitch=opts["min_pitch"],
        merge_parts_flag=opts["merge"],
        remove_unisons_flag=opts["remove_unisons"],
        remove_redundant_pitch_classes_flag=opts["remove_redundant"],
        quantize=opts["quantize"],
        add_text=opts["add_text"],
        text_type=opts["text_type"],
        text_pitch=opts["text_pitch"],
        text_offset=opts["text_offset"],
        auto_number=opts["auto_number"],
        auto_number_mode=opts["auto_mode"],
        sibelius_fingering=opts["sibelius_fingering"],
        fingering_octave_lower=opts["fingering_octave_lower"],
        retrograde_pitches=opts["retrograde_pitches"],
        retrograde_rhythms=opts["retrograde_rhythms"],
        retrograde_both=opts["retrograde_both"],
        randomize_rhythms=opts["randomize_rhythms"],
        add_guitar_tab_flag=opts["add_guitar_tab"],
        tab_octave_lower=opts["tab_octave_lower"],
        string_quartet_flag=opts["string_quartet"],
        string_quartet_rules_flag=opts["string_quartet_rules"],
        woodwind_quartet_flag=opts["woodwind_quartet"],
        woodwind_quartet_rules_flag=opts["woodwind_quartet_rules"],
        simple_beat_flag=opts["simple_beat"],
        lan_four_measures_per_system_flag=opts["lan_four_measures_per_system"],
        lan_five_systems_per_page_flag=opts["lan_five_systems_per_page"],
    )
    print(f"  MusicXML script={XML_PATH}")


def _ffmpeg(cmd, timeout):
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    if proc.returncode != 0:
        tail = (proc.stderr or proc.stdout or "ffmpeg failed").strip().splitlines()
        raise RuntimeError(tail[-1] if tail else "ffmpeg failed")
    return proc


def _kbps(value):
    try:
        return f"{int(value) / 1000:.0f} kb/s"
    except (TypeError, ValueError):
        return ""


def _print_video_details(path, data):
    fmt = data.get("format") or {}
    size = int(float(fmt.get("size") or 0))
    print("[video] ---- source ----")
    print(f"[video] file: {os.path.basename(path)}")
    print(f"[video] container: {fmt.get('format_long_name') or fmt.get('format_name')}")
    print(f"[video] duration: {float(fmt.get('duration') or 0):.3f} s")
    print(f"[video] size: {size} bytes ({size / 1048576:.2f} MB)")
    overall = _kbps(fmt.get("bit_rate"))
    if overall:
        print(f"[video] overall bitrate: {overall}")
    for key, value in (fmt.get("tags") or {}).items():
        print(f"[video] tag {key}: {value}")
    for stream in data.get("streams") or []:
        kind = stream.get("codec_type") or "data"
        codec = stream.get("codec_long_name") or stream.get("codec_name")
        print(f"[video] stream {stream.get('index')} {kind}: {codec}")
        if kind == "video":
            fps = stream.get("avg_frame_rate") or stream.get("r_frame_rate") or ""
            print(
                f"[video]   {stream.get('width')}x{stream.get('height')}"
                f"  fps {fps}  pix_fmt {stream.get('pix_fmt')}"
                f"  profile {stream.get('profile')}"
            )
            rate = _kbps(stream.get("bit_rate"))
            if rate:
                print(f"[video]   bitrate {rate}")
            if stream.get("nb_frames"):
                print(f"[video]   frames {stream.get('nb_frames')}")
        elif kind == "audio":
            print(
                f"[video]   {stream.get('sample_rate')} Hz"
                f"  channels {stream.get('channels')}"
                f"  layout {stream.get('channel_layout')}"
                f"  sample_fmt {stream.get('sample_fmt')}"
            )
            rate = _kbps(stream.get("bit_rate"))
            if rate:
                print(f"[video]   bitrate {rate}")
        for side in stream.get("side_data_list") or []:
            if side.get("rotation") is not None:
                print(f"[video]   rotation {side.get('rotation')}")


def _probe_video(path):
    proc = _ffmpeg(
        [
            "ffprobe", "-v", "error", "-print_format", "json",
            "-show_format", "-show_streams", path,
        ],
        60,
    )
    data = json.loads(proc.stdout or "{}")
    _print_video_details(path, data)
    duration = float((data.get("format") or {}).get("duration") or 0)
    width = height = 0
    has_audio = False
    for stream in data.get("streams") or []:
        if stream.get("codec_type") == "audio":
            has_audio = True
        elif stream.get("codec_type") == "video" and not width:
            width = int(stream.get("width") or 0)
            height = int(stream.get("height") or 0)
    if duration <= 0 or width <= 0 or height <= 0:
        raise RuntimeError("That file does not look like a video with a picture.")
    return duration, width, height, has_audio


def _drawtext_escape(text):
    return (
        text.replace("\\", "\\\\")
        .replace(":", "\\:")
        .replace("'", "\\'")
        .replace("%", "\\%")
        .replace("\n", " ")
    )


def _title_fontfile():
    """Avenir is on this Mac. It is not copied into the download."""
    candidates = [
        "/System/Library/Fonts/Avenir.ttc",
        "/Library/Fonts/Avenir.ttc",
        "C:\\Windows\\Fonts\\arial.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    ]
    for path in candidates:
        if os.path.isfile(path):
            return path
    return ""


def _font_name(path):
    name = os.path.basename(path).lower()
    if "avenir" in name:
        return "Avenir"
    if "arial" in name:
        return "Arial"
    if "dejavu" in name:
        return "DejaVu Sans"
    return "the default font"


def _title_filter(title):
    words = " ".join(title.split())
    font = _title_fontfile()
    font_opt = f"fontfile='{_drawtext_escape(font)}':" if font else ""
    size = 64
    if len(words) > 28:
        size = 42
    if len(words) > 48:
        size = 32
    return (
        "drawtext="
        f"{font_opt}"
        f"text='{_drawtext_escape(words)}':"
        f"fontsize={size}:fontcolor=white:"
        "borderw=3:bordercolor=black@0.75:"
        "shadowx=0:shadowy=2:shadowcolor=black@0.45:"
        "x=(w-text_w)/2:y=96:"
        "expansion=none:fix_bounds=1"
    )


def _silence_ranges(path, duration):
    proc = subprocess.run(
        [
            "ffmpeg", "-hide_banner", "-i", path,
            "-af", "silencedetect=noise=-36dB:d=0.5",
            "-f", "null", "-",
        ],
        capture_output=True, text=True, timeout=max(90, int(duration) + 30),
    )
    starts = [float(item) for item in re.findall(r"silence_start: ([0-9.]+)", proc.stderr or "")]
    ends = [float(item) for item in re.findall(r"silence_end: ([0-9.]+)", proc.stderr or "")]
    ranges = []
    end_at = 0
    for start in starts:
        end = duration
        if end_at < len(ends) and ends[end_at] >= start - 0.05:
            end = ends[end_at]
            end_at += 1
        if end > start:
            ranges.append((max(0.0, start), min(duration, end)))
    return ranges


def _kept_after_silence(duration, silences, pad=0.15):
    if not silences:
        return [(0.0, duration)]
    kept = []
    cursor = 0.0
    for start, end in silences:
        if start - cursor >= 0.08:
            kept.append((cursor, start))
        cursor = max(cursor, end)
    if duration - cursor >= 0.08:
        kept.append((cursor, duration))
    padded = []
    for start, end in kept:
        start = max(0.0, start - pad)
        end = min(duration, end + pad)
        if end - start < 0.08:
            continue
        if padded and start <= padded[-1][1] + 0.05:
            padded[-1] = (padded[-1][0], max(padded[-1][1], end))
        else:
            padded.append((start, end))
    total = sum(end - start for start, end in padded)
    if total < 1.0:
        return [(0.0, duration)]
    return padded


def _fit_under_a_minute(ranges):
    total = sum(end - start for start, end in ranges)
    if total <= SHORT_SECONDS:
        return ranges, 1.0
    speed = min(SHORT_MAX_SPEED, total / SHORT_SECONDS)
    budget = SHORT_SECONDS * speed
    fitted = []
    left = budget
    for start, end in ranges:
        if left <= 0.05:
            break
        take = min(end - start, left)
        fitted.append((start, start + take))
        left -= take
    kept = sum(end - start for start, end in fitted)
    speed = kept / SHORT_SECONDS if kept > SHORT_SECONDS else 1.0
    return fitted, speed


def _atempo_chain(speed):
    if abs(speed - 1.0) < 0.01:
        return "anull"
    parts = []
    remaining = float(speed)
    while remaining > 2.0:
        parts.append("atempo=2.0")
        remaining /= 2.0
    while remaining < 0.5:
        parts.append("atempo=0.5")
        remaining /= 0.5
    parts.append(f"atempo={remaining:.5f}")
    return ",".join(parts)


def make_short_video(in_path, out_path, ken_burns=True, skip_silence=True, title=""):
    """Wide video to a vertical clip under 60 seconds.

    2026-11-02: scale to cover 1080x1920. A left-to-right crop sweep keeps the
    sides in the shot instead of a hard center cut. Silence is removed from
    the picture and the sound together. Anything still over 59 seconds is
    sped up, at most 16x, and the rest is left off the end. A title, when
    asked for, is drawn on the finished vertical frame. Source details print
    before the encode.
    """
    duration, width, height, has_audio = _probe_video(in_path)
    if skip_silence and has_audio:
        ranges = _kept_after_silence(duration, _silence_ranges(in_path, duration))
    else:
        ranges = [(0.0, duration)]
    ranges, speed = _fit_under_a_minute(ranges)
    kept = sum(end - start for start, end in ranges)
    out_duration = max(0.2, kept / speed)
    parts = []
    vlabels = []
    alabels = []
    for index, (start, end) in enumerate(ranges):
        parts.append(
            f"[0:v]trim=start={start:.3f}:end={end:.3f},setpts=PTS-STARTPTS[v{index}]"
        )
        vlabels.append(f"[v{index}]")
        if has_audio:
            parts.append(
                f"[0:a]atrim=start={start:.3f}:end={end:.3f},asetpts=PTS-STARTPTS[a{index}]"
            )
            alabels.append(f"[a{index}]")
    if has_audio:
        concat_inputs = "".join(vlabels[i] + alabels[i] for i in range(len(ranges)))
        parts.append(f"{concat_inputs}concat=n={len(ranges)}:v=1:a=1[vc][ac]")
        parts.append(f"[ac]{_atempo_chain(speed)}[aout]")
    else:
        parts.append(f"{''.join(vlabels)}concat=n={len(ranges)}:v=1:a=0[vc]")
    parts.append(f"[vc]setpts=PTS/{speed:.5f}[vs]")
    if ken_burns:
        x_expr = f"(in_w-out_w)*min(1\\,t/{out_duration:.3f})"
    else:
        x_expr = "(in_w-out_w)/2"
    picture = (
        "[vs]scale=1080:1920:force_original_aspect_ratio=increase:flags=lanczos,"
        f"crop=1080:1920:x='max(0\\,{x_expr})':y='(in_h-out_h)/2',format=yuv420p"
    )
    if title and title.strip():
        picture += "," + _title_filter(title)
    parts.append(picture + "[vout]")
    cmd = [
        "ffmpeg", "-y", "-hide_banner", "-i", in_path,
        "-filter_complex", ";".join(parts),
        "-map", "[vout]",
    ]
    if has_audio:
        cmd.extend(["-map", "[aout]", "-c:a", "aac", "-b:a", "160k"])
    cmd.extend([
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
        "-movflags", "+faststart", out_path,
    ])
    _ffmpeg(cmd, timeout=max(180, int(duration * 3) + 60))
    removed = skip_silence and has_audio and kept + 0.4 < duration
    title_note = ""
    if title and title.strip():
        title_note = f" Title {title.strip()!r} in {_font_name(_title_fontfile())}."
    print(
        f"[short] {width}x{height}, {duration:.1f}s -> 1080x1920, "
        f"{out_duration:.1f}s, speed {speed:.2f}. "
        f"silence {'removed' if removed else 'kept'}. "
        f"{'left-to-right sweep' if ken_burns else 'center crop'}."
        f"{title_note}"
    )
    return out_duration


def index_with_error(message: str):
    safe = message.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return PAGE.replace("__ERROR__", safe), 400


@app.get("/")
def index():
    return PAGE.replace("__ERROR__", request.args.get("error") or "")


@app.get("/background.jpg")
def background():
    return send_file(BG_PATH, mimetype="image/jpeg")


@app.post("/short-video")
def short_video():
    upload = request.files.get("video")
    if upload is None or not upload.filename:
        return index_with_error("Choose a video file.")
    name = os.path.basename(upload.filename)
    lower = name.lower()
    if not lower.endswith((".mp4", ".mov", ".m4v", ".mkv", ".webm")):
        return index_with_error("Use .mp4, .mov, .m4v, .mkv, or .webm.")
    tmp_dir = tempfile.mkdtemp(prefix="midi_short_")
    in_path = os.path.join(tmp_dir, "input" + os.path.splitext(lower)[1])
    out_path = os.path.join(tmp_dir, "short.mp4")
    try:
        upload.save(in_path)
        if os.path.getsize(in_path) > VIDEO_MAX_BYTES:
            return index_with_error("Video is larger than the 500 MB limit.")
        title = (request.form.get("title_text") or "").strip()
        if _checked("add_title") and not title:
            return index_with_error("Type the title, or leave Add a title unchecked.")
        if not _checked("add_title"):
            title = ""
        make_short_video(
            in_path,
            out_path,
            ken_burns=_checked("ken_burns"),
            skip_silence=_checked("skip_silence"),
            title=title,
        )
        with open(out_path, "rb") as handle:
            payload = handle.read()
        stem = os.path.splitext(name)[0]
        return send_file(
            io.BytesIO(payload),
            as_attachment=True,
            download_name=f"{stem}_short.mp4",
            mimetype="video/mp4",
        )
    except Exception as exc:
        print(f"[{datetime.now().isoformat(timespec='seconds')}] short video failed: {exc}")
        traceback.print_exc()
        return index_with_error(f"Could not make that short: {exc}.")
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)


@app.post("/process")
def process():
    upload = request.files.get("midi")
    if upload is None or not upload.filename:
        return index_with_error("Choose a .mid or MusicXML file.")
    name = os.path.basename(upload.filename)
    lower = name.lower()
    if lower.endswith((".mid", ".midi")):
        kind = "midi"
    elif lower.endswith((".musicxml", ".xml", ".mxl")):
        kind = "xml"
    else:
        return index_with_error("Use .mid, .midi, .musicxml, .xml, or .mxl.")

    try:
        text_pitch = _optional_int("text_pitch")
        text_offset = _optional_float("text_offset")
        custom_cc = _optional_int("humanize_cc_number") if _checked("humanize_cc_custom") else None
    except ValueError as exc:
        return index_with_error(str(exc))
    if _checked("humanize_cc_custom") and custom_cc is None:
        return index_with_error("Type a MIDI CC number from 0 to 127 for the extra controller.")

    quantize = (request.form.get("quantize") or "").strip().lower() or None
    auto_mode = (request.form.get("auto_number_mode") or "finger").strip().lower()
    if auto_mode not in ("string", "finger"):
        auto_mode = "finger"
    text_type = (request.form.get("text_type") or "expression").strip().lower()
    if text_type not in ("lyric", "expression", "fingering", "articulation"):
        text_type = "expression"
    add_text = (request.form.get("add_text") or "").strip() or None
    opts = {
        "merge": _checked("merge_tracks"),
        "remove_unisons": _checked("remove_unisons"),
        "remove_redundant": _checked("remove_redundant_pitch_classes"),
        "min_pitch": 40 if _checked("guitar_range") else None,
        "quantize": quantize,
        "auto_number": _checked("auto_number"),
        "auto_mode": auto_mode,
        "sibelius_fingering": _checked("sibelius_fingering"),
        "fingering_octave_lower": _checked("fingering_octave_lower"),
        "rubato": _checked("rubato_four_bar"),
        "humanize_cc": _checked("humanize_cc"),
        "humanize_cc_number": custom_cc,
        "retrograde_pitches": _checked("retrograde_pitches"),
        "retrograde_rhythms": _checked("retrograde_rhythms"),
        "retrograde_both": _checked("retrograde_both"),
        "randomize_rhythms": _checked("randomize_rhythms"),
        "add_guitar_tab": _checked("add_guitar_tab"),
        "tab_octave_lower": _checked("tab_octave_lower"),
        "string_quartet": _checked("string_quartet"),
        "string_quartet_rules": _checked("string_quartet_rules"),
        "woodwind_quartet": _checked("woodwind_quartet"),
        "woodwind_quartet_rules": _checked("woodwind_quartet_rules"),
        "simple_beat": _checked("simple_beat"),
        "lan_four_measures_per_system": _checked("lan_four_measures_per_system"),
        "lan_five_systems_per_page": _checked("lan_five_systems_per_page"),
        "add_text": add_text,
        "text_type": text_type,
        "text_pitch": text_pitch,
        "text_offset": text_offset,
    }
    print(f"[{datetime.now().isoformat(timespec='seconds')}] {kind} {name} {opts}")

    tmp_dir = tempfile.mkdtemp(prefix="midi_lan_")
    suffix = ".mid" if kind == "midi" else os.path.splitext(name)[1]
    in_path = os.path.join(tmp_dir, "input" + suffix)
    out_path = os.path.join(tmp_dir, "output" + suffix)
    try:
        upload.save(in_path)
        if os.path.getsize(in_path) > MAX_BYTES:
            return index_with_error("File is larger than the 20 MB limit.")
        if kind == "midi":
            _process_midi(in_path, out_path, **opts)
            if opts["add_guitar_tab"]:
                xml_out = os.path.join(tmp_dir, "output.musicxml")
                xml = _load("xml_master3", XML_PATH)
                score = xml.load_score(out_path)
                xml.add_guitar_tab(score, tab_octave_lower=opts["tab_octave_lower"])
                if opts["simple_beat"]:
                    xml.add_simple_beat(score)
                if opts["lan_four_measures_per_system"] or opts["lan_five_systems_per_page"]:
                    xml.apply_lan_score_layout(
                        score,
                        four_measures_per_system=opts["lan_four_measures_per_system"],
                        five_systems_per_page=opts["lan_five_systems_per_page"],
                    )
                xml.save_score(score, xml_out)
                out_path = xml_out
                kind = "xml"
                name = os.path.splitext(name)[0] + ".musicxml"
        else:
            _process_xml(in_path, out_path, **opts)
        with open(out_path, "rb") as handle:
            payload = handle.read()
        stem, ext = os.path.splitext(name)
        return send_file(
            io.BytesIO(payload),
            as_attachment=True,
            download_name=f"{stem}_processed{ext}",
            mimetype="audio/midi" if kind == "midi" else "application/vnd.recordare.musicxml+xml",
        )
    except Exception as exc:
        print(f"[{datetime.now().isoformat(timespec='seconds')}] process failed: {exc}")
        traceback.print_exc()
        hint = ""
        if kind == "xml" and "music21" in str(exc).lower():
            hint = " Quit this window and double-click Start MIDI Manipulator again so it can finish installing."
        return index_with_error(f"Could not process that file: {exc}.{hint}")
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)


def main() -> None:
    _load("midi_master", MIDI_PATH)
    url = f"http://127.0.0.1:{PORT}/"
    print("XML MIDI Manipulator")
    print(f"  Open {url}")
    print("  Leave this window open while you use the page. Closing it stops the page.")
    threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    app.run(host=HOST, port=PORT, debug=False, threaded=True)


if __name__ == "__main__":
    main()
