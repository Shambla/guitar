@echo off
cd /d "%~dp0"

where py >nul 2>&1
if %errorlevel%==0 (
  set "PY=py -3"
) else (
  where python >nul 2>&1
  if %errorlevel%==0 (
    set "PY=python"
  ) else (
    echo.
    echo Python 3 is not installed yet.
    echo Install it from https://www.python.org/downloads/
    echo On that installer, turn on "Add python.exe to PATH".
    echo Then double-click this file again.
    echo.
    pause
    exit /b 1
  )
)

if not exist ".venv\Scripts\python.exe" (
  echo Setting up the tool. The first time takes a few minutes.
  %PY% -m venv .venv
  if errorlevel 1 (
    echo Could not create the library folder.
    pause
    exit /b 1
  )
)

call ".venv\Scripts\activate.bat"
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo Could not install the libraries in requirements.txt.
  pause
  exit /b 1
)

netstat -ano | findstr ":5013" | findstr "LISTENING" >nul
if %errorlevel%==0 (
  start "" "http://127.0.0.1:5013/"
  echo The page is already running. The browser should be open.
  exit /b 0
)

echo.
echo Leave this window open. Closing it stops the page.
echo.
python midi_manipulator_client.py
pause
