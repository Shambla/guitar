#!/bin/bash
cd "$(dirname "$0")" || exit 1

if ! command -v python3 >/dev/null 2>&1; then
  echo ""
  echo "Python 3 is not installed yet."
  echo "Install it from https://www.python.org/downloads/"
  echo "Then double-click this file again."
  echo ""
  read -r -p "Press Return to close this window."
  exit 1
fi

if [ ! -d ".venv" ]; then
  echo "Setting up the tool. The first time takes a few minutes."
  python3 -m venv .venv || {
    echo "Could not create the library folder."
    read -r -p "Press Return to close this window."
    exit 1
  }
fi

# shellcheck disable=SC1091
source ".venv/bin/activate"
python -m pip install -r requirements.txt || {
  echo "Could not install the libraries in requirements.txt."
  read -r -p "Press Return to close this window."
  exit 1
}

if lsof -nP -iTCP:5013 -sTCP:LISTEN >/dev/null 2>&1; then
  open "http://127.0.0.1:5013/"
  echo "The page is already running. The browser should be open."
  exit 0
fi

echo ""
echo "Leave this window open. Closing it stops the page."
echo ""
exec python midi_manipulator_client.py
